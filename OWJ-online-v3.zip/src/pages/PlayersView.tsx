import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { Player } from '../types';
import { 
  Users, 
  UserCheck, 
  Trophy, 
  Activity, 
  Shield, 
  Sparkles, 
  Lock, 
  Flame, 
  Award,
  ChevronLeft 
} from 'lucide-react';

export const PlayersView: React.FC = () => {
  const { players, setIsPlayerPortalOpen, loggedInPlayer, isAdminLoggedIn, setCurrentTab } = useClub();
  const [selectedPosition, setSelectedPosition] = useState<string>('all');
  const [selectedPlayerModal, setSelectedPlayerModal] = useState<Player | null>(null);

  const positions = [
    { id: 'all', label: 'همه بازیکنان' },
    { id: 'Forward', label: 'مهاجمان' },
    { id: 'Midfielder', label: 'هافبک‌ها' },
    { id: 'Defender', label: 'مدافعان' },
    { id: 'Goalkeeper', label: 'دروازه‌بان‌ها' },
  ];

  const filteredPlayers = players.filter((p) => {
    if (selectedPosition === 'all') return true;
    return p.position === selectedPosition;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-600/20 text-sky-400">
              <Users size={22} />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              کادر فنی و لیست بازیکنان تیم فوتبال OWJ
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            مشخصات فردی، بیوگرافی ورزشی، آمار گل‌ها، پاس‌گل‌ها و وضعیت انضباطی
          </p>
        </div>

        {/* Player Portal Trigger */}
        <div className="flex items-center gap-2">
          {isAdminLoggedIn && (
            <button
              onClick={() => setCurrentTab('admin')}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-colors shrink-0"
            >
              مدیریت لیست تیم
            </button>
          )}

          <button
            onClick={() => setIsPlayerPortalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-blue-600/30 transition-all active:scale-95 shrink-0"
          >
            <UserCheck size={18} />
            <span>
              {loggedInPlayer ? `پورتال ${loggedInPlayer.fullNameFa}` : 'ورود اختصاصی بازیکنان'}
            </span>
          </button>
        </div>
      </div>

      {/* Position Filters */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs border-b border-slate-800">
        {positions.map((pos) => (
          <button
            key={pos.id}
            onClick={() => setSelectedPosition(pos.id)}
            className={`px-4 py-2 rounded-xl font-bold whitespace-nowrap transition-all ${
              selectedPosition === pos.id
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {pos.label}
          </button>
        ))}
      </div>

      {/* Players Cards Grid */}
      {filteredPlayers.length === 0 ? (
        <div className="p-8 sm:p-12 rounded-2xl bg-slate-900/60 border border-slate-800 border-dashed text-center space-y-3">
          <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 text-slate-400 flex items-center justify-center">
            <Users size={22} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">لیست بازیکنان هنوز ثبت نشده است</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              تیم در حال حاضر بازیکنی در این بخش ندارد. برای افزودن بازیکنان جدید و شماره پیراهن آن‌ها وارد پنل مدیریت شوید.
            </p>
          </div>
          <button
            onClick={() => setCurrentTab('admin')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md"
          >
            <span>افزودن بازیکن در پنل مدیریت</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredPlayers.map((player) => (
            <div
              key={player.id}
              onClick={() => setSelectedPlayerModal(player)}
              className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 p-4 transition-all duration-300 hover:-translate-y-1 shadow-md flex flex-col justify-between"
            >
              <div>
                {/* Photo & Jersey */}
                <div className="relative aspect-square rounded-2xl overflow-hidden bg-slate-800 mb-3 border border-slate-700/60">
                  <img
                    src={player.photoUrl}
                    alt={player.fullNameFa}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />

                  {/* Jersey Number */}
                  <span className="absolute top-2.5 right-2.5 w-9 h-9 rounded-xl bg-blue-600/90 text-white font-black text-lg flex items-center justify-center font-sports shadow-lg backdrop-blur-xs border border-blue-400/40">
                    {player.jerseyNumber}
                  </span>

                  {/* Squad indicator */}
                  <div className="absolute bottom-2 inset-x-2 flex justify-between items-center text-[10px] font-bold">
                    <span className="px-2 py-0.5 rounded-md bg-slate-950/80 text-sky-300 backdrop-blur-xs">
                      {player.positionFa}
                    </span>
                    {player.matchSquadStatus === 'starting' && (
                      <span className="px-2 py-0.5 rounded-md bg-emerald-600/90 text-white backdrop-blur-xs flex items-center gap-1">
                        <Flame size={11} /> ترکیب اصلی
                      </span>
                    )}
                  </div>
                </div>

                {/* Names */}
                <h3 className="text-base font-bold text-white group-hover:text-sky-300 transition-colors">
                  {player.fullNameFa}
                </h3>
                <p className="text-xs text-slate-400 font-mono mt-0.5" dir="ltr">
                  {player.firstNameEn} {player.lastNameEn}
                </p>
              </div>

              {/* Quick Stats Foot */}
              <div className="mt-4 pt-3 border-t border-slate-800/80">
                <div className="grid grid-cols-3 gap-1 text-center text-xs">
                  <div className="p-1.5 rounded-lg bg-slate-800/60">
                    <span className="text-sky-400 font-black font-sports">{player.stats.matches}</span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">بازی</span>
                  </div>
                  <div className="p-1.5 rounded-lg bg-slate-800/60">
                    <span className="text-emerald-400 font-black font-sports">{player.stats.goals}</span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">گل</span>
                  </div>
                  <div className="p-1.5 rounded-lg bg-slate-800/60">
                    <span className="text-amber-400 font-black font-sports">{player.stats.assists}</span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">پاس گل</span>
                  </div>
                </div>

                <span className="block text-[11px] text-center text-sky-400 font-bold mt-2 group-hover:underline">
                  مشاهده کارنامه کامل
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Detailed Player Modal (When clicked) */}
      {selectedPlayerModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-auto p-5 sm:p-6 space-y-5">
            {/* Close button */}
            <button
              onClick={() => setSelectedPlayerModal(null)}
              className="absolute top-4 left-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              ✕
            </button>

            {/* Profile Header */}
            <div className="flex items-center gap-4">
              <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border-2 border-blue-500 shrink-0">
                <img
                  src={selectedPlayerModal.photoUrl}
                  alt={selectedPlayerModal.fullNameFa}
                  className="w-full h-full object-cover"
                />
                <span className="absolute bottom-1 right-1 px-2 py-0.5 rounded-md bg-blue-600 text-white font-black text-xs font-sports">
                  #{selectedPlayerModal.jerseyNumber}
                </span>
              </div>

              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-blue-600/30 text-sky-400 text-xs font-bold border border-blue-500/30">
                  {selectedPlayerModal.positionFa} ({selectedPlayerModal.position})
                </span>
                <h2 className="text-lg sm:text-xl font-black text-white mt-1">
                  {selectedPlayerModal.fullNameFa}
                </h2>
                <p className="text-xs text-slate-400 font-mono" dir="ltr">
                  {selectedPlayerModal.firstNameEn} {selectedPlayerModal.lastNameEn}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  شناسه سازمانی: <strong className="text-sky-300 font-mono" dir="ltr">{selectedPlayerModal.playerId}</strong>
                </p>
              </div>
            </div>

            {/* Physical Attributes */}
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="p-2 rounded-xl bg-slate-800 border border-slate-700/60">
                <span className="text-slate-400 text-[10px] block">سن</span>
                <span className="font-bold text-white font-sports text-sm">{selectedPlayerModal.age} سال</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-800 border border-slate-700/60">
                <span className="text-slate-400 text-[10px] block">قد</span>
                <span className="font-bold text-white font-sports text-sm">{selectedPlayerModal.heightCm} cm</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-800 border border-slate-700/60">
                <span className="text-slate-400 text-[10px] block">وزن</span>
                <span className="font-bold text-white font-sports text-sm">{selectedPlayerModal.weightKg} kg</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-800 border border-slate-700/60">
                <span className="text-slate-400 text-[10px] block">پای تخصصی</span>
                <span className="font-bold text-sky-400 text-xs mt-0.5 block">{selectedPlayerModal.preferredFoot}</span>
              </div>
            </div>

            {/* Season Stats Table */}
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Activity size={16} className="text-sky-400" />
                <span>آمار جامع در رقابت‌های فصل تیم OWJ</span>
              </h4>

              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center">
                <div className="p-2 rounded-xl bg-slate-900">
                  <span className="text-sm font-black text-white font-sports">{selectedPlayerModal.stats.matches}</span>
                  <span className="block text-[10px] text-slate-400 mt-0.5">بازی</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900">
                  <span className="text-sm font-black text-emerald-400 font-sports">{selectedPlayerModal.stats.goals}</span>
                  <span className="block text-[10px] text-slate-400 mt-0.5">گل</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900">
                  <span className="text-sm font-black text-amber-400 font-sports">{selectedPlayerModal.stats.assists}</span>
                  <span className="block text-[10px] text-slate-400 mt-0.5">پاس‌گل</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900">
                  <span className="text-sm font-black text-yellow-400 font-sports">{selectedPlayerModal.stats.yellowCards}</span>
                  <span className="block text-[10px] text-slate-400 mt-0.5">کارت زرد</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900">
                  <span className="text-sm font-black text-red-400 font-sports">{selectedPlayerModal.stats.redCards}</span>
                  <span className="block text-[10px] text-slate-400 mt-0.5">کارت قرمز</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900">
                  <span className="text-sm font-black text-sky-400 font-sports">{selectedPlayerModal.stats.minutesPlayed}</span>
                  <span className="block text-[10px] text-slate-400 mt-0.5">دقایق</span>
                </div>
              </div>
            </div>

            {/* Squad status */}
            <div className="flex items-center justify-between text-xs text-slate-300 p-3 rounded-xl bg-slate-800/40">
              <span>وضعیت لیست مسابقه:</span>
              <span className="font-bold text-emerald-400">
                {selectedPlayerModal.matchSquadStatus === 'starting' ? 'یازده بازیکن فیکس ترکیب اصلی' : 'بازیکن تعویضی'}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
