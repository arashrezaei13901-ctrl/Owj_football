import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { NewsCard } from '../components/NewsCard';
import { NewsCategory } from '../types';
import { 
  Search, 
  Filter, 
  Tag, 
  Plus, 
  Clock, 
  Eye, 
  Heart, 
  Pin,
  Newspaper 
} from 'lucide-react';

export const NewsView: React.FC = () => {
  const { news, isAdminLoggedIn, setCurrentTab } = useClub();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'popular' | 'likes'>('newest');

  const categories: { id: string; label: string }[] = [
    { id: 'all', label: 'همه اخبار' },
    { id: 'team', label: 'اخبار تیم' },
    { id: 'match_report', label: 'گزارش مسابقه' },
    { id: 'transfers', label: 'نقل و انتقالات' },
    { id: 'interview', label: 'مصاحبه اختصاصی' },
    { id: 'training', label: 'تمرینات' },
    { id: 'academy', label: 'آکادمی فوتبال' },
  ];

  const filteredNews = news
    .filter((item) => {
      const matchCat = selectedCategory === 'all' || item.category === selectedCategory;
      const matchQuery = 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.tags && item.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())));
      return matchCat && matchQuery;
    })
    .sort((a, b) => {
      // Keep pinned news on top regardless
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;

      if (sortBy === 'popular') return b.viewsCount - a.viewsCount;
      if (sortBy === 'likes') return b.likesCount - a.likesCount;
      return 0; // Default order is newest first
    });

  return (
    <div className="space-y-6 pb-12">
      {/* Header with Search and Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-600/20 text-sky-400">
              <Newspaper size={22} />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              مرکز اخبار و اطلاع‌رسانی باشگاه OWJ
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            آخرین رویدادها، بیانیه‌های فنی، گزارش بازی‌ها و مصاحبه‌های اختصاصی
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Admin shortcut button */}
          {isAdminLoggedIn && (
            <button
              onClick={() => setCurrentTab('admin')}
              className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-blue-600/30 transition-all shrink-0"
            >
              <Plus size={16} />
              <span>انتشار خبر</span>
            </button>
          )}

          {/* Search bar */}
          <div className="relative flex-1 sm:w-64">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو در متن اخبار..."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Category Pills & Sorting Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-800">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-400 self-end sm:self-center">
          <span>مرتب‌سازی:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-300 text-xs focus:outline-hidden focus:border-blue-500"
          >
            <option value="newest">جدیدترین</option>
            <option value="popular">پربازدیدترین</option>
            <option value="likes">محبوب‌ترین (لایک)</option>
          </select>
        </div>
      </div>

      {/* News Grid */}
      {filteredNews.length === 0 ? (
        <div className="p-8 sm:p-12 text-center rounded-2xl bg-slate-900/60 border border-slate-800 border-dashed space-y-3">
          <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 text-slate-400 flex items-center justify-center">
            <Newspaper size={22} />
          </div>
          <p className="text-sm font-bold text-slate-300">
            {news.length === 0 ? 'هنوز خبری منتشر نشده است' : 'خبری مطابق فیلتر یافت نشد'}
          </p>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            {news.length === 0 
              ? 'برنامه خالی و آماده ورود اطلاعات است. برای درج اولین خبر، روی دکمه زیر کلیک کنید.'
              : 'با دسته‌بندی یا عبارت جستجوی دیگری مجدداً تلاش کنید.'}
          </p>
          <button
            onClick={() => setCurrentTab('admin')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md"
          >
            <Plus size={15} />
            <span>ورود به پنل مدیریت برای انتشار خبر</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredNews.map((item, idx) => (
            <NewsCard key={item.id} news={item} featured={idx === 0 && selectedCategory === 'all' && !searchQuery} />
          ))}
        </div>
      )}
    </div>
  );
};
