import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { 
  Film, 
  Image as ImageIcon, 
  UploadCloud, 
  Play, 
  Eye, 
  Clock, 
  Download, 
  Layers, 
  Sparkles, 
  CheckCircle2, 
  Filter 
} from 'lucide-react';

export const MediaView: React.FC = () => {
  const { 
    videos, 
    albums, 
    photos, 
    setSelectedVideo, 
    setSelectedPhotoIndex, 
    setIsUploadModalOpen,
    activeUploads,
    isAdminLoggedIn,
    setCurrentTab
  } = useClub();

  const [activeMediaTab, setActiveMediaTab] = useState<'videos' | 'photos'>('videos');
  const [videoCategory, setVideoCategory] = useState('all');
  const [selectedAlbumId, setSelectedAlbumId] = useState<string>('all');

  const videoCategories = [
    { id: 'all', label: 'همه ویدیوها' },
    { id: 'خلاصه بازی', label: 'خلاصه بازی‌ها' },
    { id: 'گل‌ها و مهارت‌ها', label: 'گل‌ها و مهارت‌ها' },
    { id: 'مستند و پشت صحنه', label: 'مستند و پشت صحنه' },
    { id: 'مصاحبه اختصاصی', label: 'مصاحبه‌ها' },
  ];

  const filteredVideos = videos.filter((v) => 
    videoCategory === 'all' || v.category === videoCategory
  );

  const filteredPhotos = selectedAlbumId === 'all' 
    ? photos 
    : photos.filter(p => p.albumId === selectedAlbumId);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-600/20 text-sky-400">
              <Film size={22} />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              رسانه و چندرسانه‌ای تیم فوتبال OWJ
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            ویدیوهای با کیفیت بالا، خلاصه بازی‌ها و گزارش تصویری از تمرینات و مسابقات
          </p>
        </div>

        {/* Resumable Upload CTA button */}
        <button
          onClick={() => setIsUploadModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-500 hover:to-sky-400 text-white text-xs sm:text-sm font-bold shadow-lg shadow-blue-600/30 transition-all active:scale-95 shrink-0"
        >
          <UploadCloud size={18} />
          <span>آپلود ویدیوی حجیم (تکه‌ای و قابل ادامه)</span>
        </button>
      </div>

      {/* Active Uploads Notice (if any) */}
      {activeUploads.length > 0 && (
        <div 
          onClick={() => setIsUploadModalOpen(true)}
          className="p-3.5 rounded-2xl bg-blue-950/70 border border-blue-500/50 flex items-center justify-between gap-3 cursor-pointer hover:bg-blue-950 transition-colors shadow-md"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-600 text-white animate-pulse">
              <Layers size={18} />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">
                {activeUploads.length} فرآیند آپلود تکه‌ای در جریان است
              </span>
              <span className="text-[11px] text-slate-300">
                برای مدیریت، مشاهده پیشرفت لحظه‌ای یا توقف/ادامه کلیک کنید.
              </span>
            </div>
          </div>
          <span className="text-xs text-sky-400 font-bold underline">
            مدیریت صف
          </span>
        </div>
      )}

      {/* Media Type Switcher (Videos vs Photos) */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-900 border border-slate-800 w-full sm:w-auto self-start">
        <button
          onClick={() => setActiveMediaTab('videos')}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeMediaTab === 'videos'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Film size={16} />
          <span>ویدیوها ({videos.length})</span>
        </button>

        <button
          onClick={() => setActiveMediaTab('photos')}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeMediaTab === 'photos'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <ImageIcon size={16} />
          <span>آلبوم‌ها و تصاویر ({photos.length})</span>
        </button>
      </div>

      {/* 1. VIDEOS TAB */}
      {activeMediaTab === 'videos' && (
        <div className="space-y-5">
          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            {videoCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setVideoCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                  videoCategory === cat.id
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Videos Grid */}
          {filteredVideos.length === 0 ? (
            <div className="p-8 sm:p-12 text-center rounded-2xl bg-slate-900/60 border border-slate-800 border-dashed space-y-3">
              <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 text-slate-400 flex items-center justify-center">
                <Film size={22} />
              </div>
              <p className="text-sm font-bold text-slate-300">
                {videos.length === 0 ? 'هنوز ویدیویی آپلود نشده است' : 'ویدیویی در این دسته‌بندی یافت نشد'}
              </p>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                می‌توانید با دکمه آپلود ویدیوی حجیم یا از طریق پنل مدیریت، ویدیوهای خلاصه بازی‌ها را بارگذاری فرمایید.
              </p>
              <button
                onClick={() => setIsUploadModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md"
              >
                <UploadCloud size={15} />
                <span>شروع آپلود ویدیو</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredVideos.map((video) => (
                <div
                  key={video.id}
                  onClick={() => setSelectedVideo(video)}
                  className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 overflow-hidden shadow-md transition-all duration-300 flex flex-col hover:-translate-y-1"
                >
                  {/* Thumbnail Stage */}
                  <div className="relative aspect-video bg-slate-800 overflow-hidden">
                    <img
                      src={video.thumbnailUrl}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/20 transition-colors">
                      <div className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
                        <Play size={20} className="fill-white mr-0.5" />
                      </div>
                    </div>

                    <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded bg-black/80 text-white text-[11px] font-mono">
                      {video.duration}
                    </span>
                    <span className="absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded-lg bg-blue-600/90 text-white text-xs font-bold shadow-md">
                      {video.category}
                    </span>
                  </div>

                  {/* Video Info */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-sky-300 transition-colors line-clamp-2 leading-relaxed">
                        {video.title}
                      </h3>
                      <p className="mt-1 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                        {video.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <Eye size={13} className="text-slate-500" />
                        {video.viewsCount.toLocaleString('fa-IR')} بازدید
                      </span>
                      <span className="text-sky-400 font-bold group-hover:translate-x-[-3px] transition-transform">
                        تماشا در پلیر اختصاصی
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. PHOTOS & ALBUMS TAB */}
      {activeMediaTab === 'photos' && (
        <div className="space-y-6">
          {/* Albums Row */}
          <div>
            <h3 className="text-sm font-bold text-slate-300 mb-3 flex items-center gap-1.5">
              <Filter size={15} className="text-sky-400" />
              <span>فیلتر بر اساس آلبوم‌های رسمی تیم:</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <button
                onClick={() => setSelectedAlbumId('all')}
                className={`p-3 rounded-xl border text-right transition-all ${
                  selectedAlbumId === 'all'
                    ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-600/20'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                <span className="text-xs font-bold block">همه تصاویر</span>
                <span className="text-[11px] opacity-80 mt-0.5 block">{photos.length} تصویر با کیفیت</span>
              </button>

              {albums.map((alb) => (
                <button
                  key={alb.id}
                  onClick={() => setSelectedAlbumId(alb.id)}
                  className={`p-3 rounded-xl border text-right transition-all ${
                    selectedAlbumId === alb.id
                      ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-600/20'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  <span className="text-xs font-bold block truncate">{alb.title}</span>
                  <span className="text-[11px] opacity-80 mt-0.5 block">{alb.photosCount} تصویر • {alb.category}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Photos Grid */}
          {filteredPhotos.length === 0 ? (
            <div className="p-8 sm:p-12 text-center rounded-2xl bg-slate-900/60 border border-slate-800 border-dashed space-y-3">
              <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 text-slate-400 flex items-center justify-center">
                <ImageIcon size={22} />
              </div>
              <p className="text-sm font-bold text-slate-300">
                {photos.length === 0 ? 'هنوز عکسی در گالری ثبت نشده است' : 'عکسی در این آلبوم یافت نشد'}
              </p>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                از طریق پنل مدیریت یا دکمه درج تصویر می‌توانید آلبوم‌ها و تصاویر جدید باشگاه را اضافه کنید.
              </p>
              <button
                onClick={() => setCurrentTab('admin')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md"
              >
                <span>مدیریت گالری در پنل ادمین</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredPhotos.map((photo, idx) => (
                <div
                  key={photo.id}
                  onClick={() => setSelectedPhotoIndex(idx)}
                  className="group relative aspect-4/3 rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 hover:border-blue-500/50 cursor-pointer shadow-md transition-all"
                >
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />

                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-3 flex flex-col justify-end">
                    <span className="text-xs font-bold text-white truncate">
                      {photo.title}
                    </span>
                    {photo.caption && (
                      <span className="text-[10px] text-slate-300 truncate mt-0.5">
                        {photo.caption}
                      </span>
                    )}
                    <span className="text-[10px] text-sky-400 font-semibold mt-1">
                      کلیک برای مشاهده با کیفیت اصلی و دانلود
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
