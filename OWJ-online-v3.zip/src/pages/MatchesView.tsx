import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { 
  Trophy, 
  Calendar, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  Flame, 
  ChevronLeft,
  Award,
  Sparkles,
  PlusCircle,
  Inbox
} from 'lucide-react';
import { Logo } from '../components/Logo';
import { TeamLogo } from '../components/TeamLogo';

export const MatchesView: React.FC = () => {
  const { matches, clubInfo, isAdminLoggedIn, setCurrentTab, standings } = useClub();
  const [activeSubTab, setActiveSubTab] = useState<'fixtures' | 'table'>('fixtures');

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-600/20 text-sky-400">
              <Trophy size={22} />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              برنامه مسابقات و جدول مسابقات تیم OWJ
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            جدول رده‌بندی، نتایج زنده، ساعت شروع بازی‌ها و گزارش استادیوم
          </p>
        </div>

        <button
          onClick={() => setCurrentTab('admin')}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors self-start sm:self-auto shadow-md"
        >
          <PlusCircle size={15} />
          <span>ثبت و ویرایش مسابقات از پنل مدیریت</span>
        </button>
      </div>

      {/* Sub tabs: Fixtures vs League Table */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-900 border border-slate-800 w-full sm:w-auto self-start">
        <button
          onClick={() => setActiveSubTab('fixtures')}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeSubTab === 'fixtures'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Calendar size={16} />
          <span>برنامه و نتایج بازی‌ها ({matches.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('table')}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeSubTab === 'table'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Trophy size={16} />
          <span>جدول رده‌بندی مسابقات</span>
        </button>
      </div>

      {/* 1. FIXTURES TAB */}
      {activeSubTab === 'fixtures' && (
        <div className="space-y-4">
          {matches.length === 0 ? (
            <div className="p-8 sm:p-12 rounded-2xl bg-slate-900/60 border border-slate-800 border-dashed text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 text-slate-400 flex items-center justify-center">
                <Calendar size={22} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">هنوز دیداری ثبت نشده است</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  برنامه بازی‌ها خالی است. از پنل مدیریت می‌توانید مسابقات آینده، حریفان، ورزشگاه و نتایج بازی‌ها را وارد کنید.
                </p>
              </div>
              <button
                onClick={() => setCurrentTab('admin')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md"
              >
                <PlusCircle size={15} />
                <span>افزودن بازی جدید</span>
              </button>
            </div>
          ) : (
            matches.map((match) => (
              <div
                key={match.id}
                className={`rounded-2xl border p-4 sm:p-5 transition-all shadow-md ${
                  match.status === 'live'
                    ? 'bg-gradient-to-r from-red-950/60 via-slate-900 to-slate-900 border-red-500/50'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                {/* Competition & Status Tag */}
                <div className="flex items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-800">
                  <span className="px-2.5 py-1 rounded-lg bg-blue-600/20 text-sky-400 text-xs font-bold border border-blue-500/20">
                    {match.competition}
                  </span>

                  <div className="flex items-center gap-2 text-xs">
                    {match.status === 'live' && (
                      <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-600 text-white font-black text-xs animate-pulse">
                        <span className="w-2 h-2 rounded-full bg-white" />
                        در حال برگزاری (دقیقه {match.liveMinute || 65}')
                      </span>
                    )}
                    {match.status === 'finished' && (
                      <span className="flex items-center gap-1 text-emerald-400 font-bold">
                        <CheckCircle2 size={14} /> پایان بازی
                      </span>
                    )}
                    {match.status === 'upcoming' && (
                      <span className="flex items-center gap-1 text-sky-400 font-bold">
                        <Clock size={14} /> مسابقه پیش‌رو
                      </span>
                    )}
                  </div>
                </div>

                {/* Match Versus Board */}
                <div className="flex items-center justify-between gap-2 sm:gap-6 py-2">
                  {/* Home Team */}
                  <div className="flex-1 text-center sm:text-right flex flex-col sm:flex-row items-center gap-3">
                    <TeamLogo
                      teamName={match.homeTeam}
                      logoUrl={match.homeLogo}
                      size="md"
                    />
                    <div>
                      <h3 className="text-xs sm:text-base font-bold text-white">
                        {match.homeTeam}
                      </h3>
                      <span className="text-[11px] text-sky-400 font-medium hidden sm:block">میزبان مسابقه</span>
                    </div>
                  </div>

                  {/* Score or VS Badge */}
                  <div className="px-3 sm:px-6 py-2 rounded-2xl bg-slate-950/80 border border-slate-800 text-center shrink-0">
                    {match.status === 'finished' || match.status === 'live' ? (
                      <div className="flex items-center gap-2 sm:gap-3 text-xl sm:text-3xl font-black font-sports text-white">
                        <span className="text-sky-400">{match.homeScore ?? 0}</span>
                        <span className="text-slate-500">-</span>
                        <span>{match.awayScore ?? 0}</span>
                      </div>
                    ) : (
                      <span className="text-sm sm:text-base font-black text-sky-400 font-sports">
                        VS
                      </span>
                    )}
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {match.time}
                    </span>
                  </div>

                  {/* Away Team */}
                  <div className="flex-1 text-center sm:text-left flex flex-col sm:flex-row-reverse items-center gap-3">
                    <TeamLogo
                      teamName={match.awayTeam}
                      logoUrl={match.awayLogo}
                      size="md"
                    />
                    <div>
                      <h3 className="text-xs sm:text-base font-bold text-white">
                        {match.awayTeam}
                      </h3>
                      <span className="text-[11px] text-slate-400 font-medium hidden sm:block">تیم مهمان</span>
                    </div>
                  </div>
                </div>

                {/* Match Details & Venue Footer */}
                <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Calendar size={13} className="text-slate-500" />
                      {match.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin size={13} className="text-slate-500" />
                      {match.venue}
                    </span>
                  </div>

                  {match.summary && (
                    <span className="text-slate-300 font-medium">
                      {match.summary}
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* 2. LEAGUE TABLE */}
      {activeSubTab === 'table' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-4 bg-slate-850 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award size={18} className="text-amber-400" />
                <h3 className="text-sm sm:text-base font-bold text-white">
                  جدول مسابقات
                </h3>
              </div>
            </div>

            {standings.length === 0 ? (
              <div className="p-8 text-center space-y-3">
                <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 text-slate-400 flex items-center justify-center">
                  <Trophy size={22} />
                </div>
                <h4 className="text-sm font-bold text-white">جدول مسابقات خالی است</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  با ثبت نتایج مسابقات در پنل مدیریت، جدول رده‌بندی لیگ به‌صورت هوشمند به‌روزرسانی خواهد شد.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs text-slate-300">
                  <thead className="bg-slate-950/60 text-slate-400 font-semibold border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-3 text-center">رتبه</th>
                      <th className="py-3 px-3">نام تیم</th>
                      <th className="py-3 px-2 text-center">بازی</th>
                      <th className="py-3 px-2 text-center">برد</th>
                      <th className="py-3 px-2 text-center">مساوی</th>
                      <th className="py-3 px-2 text-center">باخت</th>
                      <th className="py-3 px-2 text-center hidden sm:table-cell">گل‌زده</th>
                      <th className="py-3 px-2 text-center hidden sm:table-cell">گل‌خورده</th>
                      <th className="py-3 px-2 text-center">تفاضل</th>
                      <th className="py-3 px-3 text-center font-bold text-white">امتیاز</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {standings.map((row) => (
                      <tr 
                        key={row.rank}
                        className={row.isOuj ? 'bg-blue-900/30 text-white font-bold' : 'hover:bg-slate-800/40'}
                      >
                        <td className="py-3 px-3 text-center">
                          <span className={`w-6 h-6 rounded-full inline-flex items-center justify-center font-sports ${
                            row.rank === 1 ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400'
                          }`}>
                            {row.rank}
                          </span>
                        </td>
                        <td className="py-3 px-3 flex items-center gap-2">
                          <TeamLogo 
                            teamName={row.team || (row as any).teamName || ''} 
                            isOwj={Boolean(row.isOuj || (row as any).isOwj)} 
                            size="xs" 
                          />
                          <span className={row.isOuj ? 'text-sky-300 font-black' : ''}>{row.team || (row as any).teamName}</span>
                        </td>
                        <td className="py-3 px-2 text-center font-sports">{row.played}</td>
                        <td className="py-3 px-2 text-center font-sports text-emerald-400">{row.win}</td>
                        <td className="py-3 px-2 text-center font-sports text-slate-400">{row.draw}</td>
                        <td className="py-3 px-2 text-center font-sports text-red-400">{row.loss}</td>
                        <td className="py-3 px-2 text-center font-sports hidden sm:table-cell">{row.gf}</td>
                        <td className="py-3 px-2 text-center font-sports hidden sm:table-cell">{row.ga}</td>
                        <td className="py-3 px-2 text-center font-sports text-slate-300" dir="ltr">{row.gd}</td>
                        <td className="py-3 px-3 text-center font-black font-sports text-sm text-sky-400">
                          {row.pts}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
