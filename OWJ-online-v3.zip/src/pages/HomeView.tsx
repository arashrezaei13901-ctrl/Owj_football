import React from 'react';
import { useClub } from '../context/ClubContext';
import { BreakingNewsTicker } from '../components/BreakingNewsTicker';
import { UpcomingMatchBanner } from '../components/UpcomingMatchBanner';
import { NewsCard } from '../components/NewsCard';
import { 
  ChevronLeft, 
  Play, 
  Sparkles, 
  Users, 
  Film, 
  Image as ImageIcon, 
  PlusCircle,
  Newspaper,
  Calendar,
  Layers
} from 'lucide-react';
import { Logo } from '../components/Logo';

export const HomeView: React.FC = () => {
  const { 
    news, 
    videos, 
    photos, 
    players, 
    setCurrentTab, 
    setSelectedVideo, 
    setSelectedPhotoIndex,
    clubInfo
  } = useClub();

  // Featured news and latest news
  const featuredNews = news.find(n => n.isFeatured) || news[0];
  const recentNews = news.filter(n => n.id !== featuredNews?.id).slice(0, 3);
  const topVideos = videos.slice(0, 3);
  const recentPhotos = photos.slice(0, 6);
  const starPlayers = players.filter(p => p.isActive).slice(0, 4);

  const hasAnyContent = news.length > 0 || videos.length > 0 || players.length > 0 || photos.length > 0;

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Breaking News Ticker (only displays if there are breaking/pinned news) */}
      <BreakingNewsTicker />

      {/* 2. Upcoming Match Countdown Banner (only displays if upcoming matches exist) */}
      <UpcomingMatchBanner />

      {/* 3. Hero Club Banner & Identity */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-900 via-blue-950 to-slate-950 border border-blue-600/30 p-5 sm:p-8 shadow-2xl">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-blue-600/40 text-sky-300 text-xs font-bold border border-blue-400/30 flex items-center gap-1.5">
              <Sparkles size={13} />
              {clubInfo.currentSeason ? `فصل رسمی ${clubInfo.currentSeason}` : 'فصل رسمی ۱۴۰۵_۱۴۰۶'}
            </span>
            {clubInfo.motto && (
              <span className="text-xs text-slate-300">
                {clubInfo.motto}
              </span>
            )}
          </div>

          <h1 className="text-xl sm:text-3xl font-black text-white leading-tight">
            باشگاه فرهنگی ورزشی و تیم فوتبال <span className="text-sky-400 font-sports tracking-wider">OWJ</span>
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl">
            پایگاه رسمی اطلاع‌رسانی، انتشار لحظه‌ای گل‌ها، گزارش مسابقات، ویدیوهای باکیفیت و سیستم هماهنگی کادر فنی و بازیکنان تیم فوتبال OWJ.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setCurrentTab('admin')}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/40 transition-all flex items-center gap-1.5 active:scale-95"
            >
              <PlusCircle size={15} />
              <span>ورود به پنل مدیریت برای درج اطلاعات</span>
            </button>

            <button
              onClick={() => setCurrentTab('news')}
              className="px-4 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all flex items-center gap-1.5"
            >
              <span>مشاهده بخش اخبار</span>
              <ChevronLeft size={16} />
            </button>
          </div>
        </div>

        {/* Subtle background crest */}
        <div className="absolute left-4 -bottom-6 opacity-15 pointer-events-none transform scale-150 rotate-12 hidden sm:block">
          <Logo size="lg" showText={false} />
        </div>
      </div>

      {/* Clean Welcome Card when all sections are empty */}
      {!hasAnyContent && (
        <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 text-center space-y-4 shadow-xl">
          <div className="max-w-md mx-auto space-y-2">
            <h3 className="text-base font-bold text-white">
              برنامه کاملاً خالی و آماده ثبت اطلاعات شماست
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              تمامی موارد و داده‌های پیش‌فرض و اضافی پاکسازی شدند. اکنون می‌توانید از طریق پنل مدیریت، اخبار تیم، بازیکنان، مسابقات و ویدیوها را ثبت کنید.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-2xl mx-auto pt-2">
            <button
              onClick={() => setCurrentTab('admin')}
              className="p-3 rounded-2xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white transition-all flex flex-col items-center gap-2 group"
            >
              <div className="p-2 rounded-xl bg-blue-600/20 text-sky-400 group-hover:scale-110 transition-transform">
                <Newspaper size={18} />
              </div>
              <span className="text-xs font-bold">ثبت خبر جدید</span>
            </button>

            <button
              onClick={() => setCurrentTab('admin')}
              className="p-3 rounded-2xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white transition-all flex flex-col items-center gap-2 group"
            >
              <div className="p-2 rounded-xl bg-emerald-600/20 text-emerald-400 group-hover:scale-110 transition-transform">
                <Users size={18} />
              </div>
              <span className="text-xs font-bold">افزودن بازیکن</span>
            </button>

            <button
              onClick={() => setCurrentTab('admin')}
              className="p-3 rounded-2xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white transition-all flex flex-col items-center gap-2 group"
            >
              <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400 group-hover:scale-110 transition-transform">
                <Film size={18} />
              </div>
              <span className="text-xs font-bold">بارگذاری ویدیو</span>
            </button>

            <button
              onClick={() => setCurrentTab('admin')}
              className="p-3 rounded-2xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white transition-all flex flex-col items-center gap-2 group"
            >
              <div className="p-2 rounded-xl bg-amber-600/20 text-amber-400 group-hover:scale-110 transition-transform">
                <Calendar size={18} />
              </div>
              <span className="text-xs font-bold">ثبت مسابقه</span>
            </button>
          </div>
        </div>
      )}

      {/* 4. News Section (only renders when news exist) */}
      {news.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
              <h2 className="text-base sm:text-xl font-bold text-white">اخبار و گزارشات تیم</h2>
            </div>
            <button
              onClick={() => setCurrentTab('news')}
              className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300 font-bold transition-colors"
            >
              <span>آرشیو همه اخبار</span>
              <ChevronLeft size={16} />
            </button>
          </div>

          {featuredNews && <NewsCard news={featuredNews} featured={true} />}
          {recentNews.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {recentNews.map((n) => (
                <NewsCard key={n.id} news={n} />
              ))}
            </div>
          )}
        </section>
      )}

      {/* 5. Video Highlights Section (only renders when videos exist) */}
      {videos.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-600/20 text-sky-400">
                <Film size={18} />
              </div>
              <h2 className="text-base sm:text-xl font-bold text-white">ویدیوها و خلاصه بازی‌ها</h2>
            </div>
            <button
              onClick={() => setCurrentTab('media')}
              className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300 font-bold transition-colors"
            >
              <span>تمام ویدیوها</span>
              <ChevronLeft size={16} />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {topVideos.map((video) => (
              <div
                key={video.id}
                onClick={() => setSelectedVideo(video)}
                className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/40 overflow-hidden shadow-md transition-all flex flex-col"
              >
                <div className="relative aspect-video bg-slate-800 overflow-hidden">
                  <img
                    src={video.thumbnailUrl}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/20 transition-colors">
                    <div className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <Play size={20} className="fill-white mr-0.5" />
                    </div>
                  </div>

                  <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/80 text-white text-[11px] font-mono">
                    {video.duration}
                  </span>
                  <span className="absolute top-2 right-2 px-2 py-0.5 rounded bg-blue-600/80 backdrop-blur-xs text-white text-[11px] font-bold">
                    {video.category}
                  </span>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-sky-300 transition-colors line-clamp-2">
                    {video.title}
                  </h4>
                  <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
                    <span>{video.viewsCount.toLocaleString('fa-IR')} بازدید</span>
                    <span className="text-sky-400 font-medium">پخش آنلاین</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Squad Highlights (only renders when players exist) */}
      {players.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-600/20 text-sky-400">
                <Users size={18} />
              </div>
              <h2 className="text-base sm:text-xl font-bold text-white">ترکیب و بازیکنان تیم</h2>
            </div>
            <button
              onClick={() => setCurrentTab('players')}
              className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300 font-bold transition-colors"
            >
              <span>مشاهده ترکیب کامل</span>
              <ChevronLeft size={16} />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            {starPlayers.map((player) => (
              <div
                key={player.id}
                onClick={() => setCurrentTab('players')}
                className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 p-3 sm:p-4 text-center transition-all duration-300 hover:-translate-y-1 shadow-md"
              >
                <div className="relative mx-auto w-20 h-20 sm:w-24 sm:h-24 mb-3">
                  <img
                    src={player.photoUrl}
                    alt={player.fullNameFa}
                    className="w-full h-full rounded-2xl object-cover border-2 border-slate-700 group-hover:border-sky-400 transition-colors shadow-md"
                    loading="lazy"
                  />
                  <span className="absolute -bottom-2 right-1/2 translate-x-1/2 px-2.5 py-0.5 rounded-full bg-blue-600 text-white font-black text-xs font-sports shadow-md border border-slate-900">
                    {player.jerseyNumber}
                  </span>
                </div>

                <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-sky-300 transition-colors truncate">
                  {player.fullNameFa}
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {player.positionFa}
                </p>

                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-around text-[10px] text-slate-400">
                  <span>{player.stats.goals} گل</span>
                  <span>•</span>
                  <span>{player.stats.assists} پاس گل</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 7. Gallery Snapshot Preview (only renders when photos exist) */}
      {photos.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-600/20 text-sky-400">
                <ImageIcon size={18} />
              </div>
              <h2 className="text-base sm:text-xl font-bold text-white">گالری تصاویر و آلبوم‌ها</h2>
            </div>
            <button
              onClick={() => setCurrentTab('media')}
              className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300 font-bold transition-colors"
            >
              <span>گالری تصاویر</span>
              <ChevronLeft size={16} />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 sm:gap-3">
            {recentPhotos.map((photo, idx) => (
              <div
                key={photo.id}
                onClick={() => setSelectedPhotoIndex(idx)}
                className="group relative aspect-square rounded-xl overflow-hidden bg-slate-800 border border-slate-800 cursor-pointer"
              >
                <img
                  src={photo.url}
                  alt={photo.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-2 flex items-end">
                  <span className="text-[10px] text-white font-bold truncate">
                    {photo.title}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
