import React, { useState, useEffect } from 'react';
import { useClub } from '../context/ClubContext';
import { Calendar, MapPin, Clock, Trophy, ChevronLeft } from 'lucide-react';
import { TeamLogo } from './TeamLogo';

export const UpcomingMatchBanner: React.FC = () => {
  const { matches, setCurrentTab } = useClub();
  const nextMatch = matches.find(m => m.status === 'upcoming') || matches[0];
  const lastMatch = matches.find(m => m.status === 'finished');

  // Realistic countdown simulator
  const [timeLeft, setTimeLeft] = useState({ days: 3, hours: 14, minutes: 28, seconds: 45 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        }
        return { ...prev, seconds: 59, minutes: Math.max(0, prev.minutes - 1) };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!nextMatch) return null;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-950 via-slate-900 to-slate-950 border border-blue-600/30 p-4 sm:p-6 shadow-xl">
      {/* Background soccer pitch abstract lines */}
      <div className="absolute inset-0 pointer-events-none opacity-10 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]" />

      {/* Top Header */}
      <div className="flex items-center justify-between gap-2 mb-4 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-blue-600/20 text-sky-400">
            <Trophy size={16} />
          </span>
          <span className="text-xs sm:text-sm font-bold text-slate-200">
            {nextMatch.competition}
          </span>
        </div>
        <button
          onClick={() => setCurrentTab('matches')}
          className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300 font-medium"
        >
          <span>تقویم و نتایج کامل</span>
          <ChevronLeft size={14} />
        </button>
      </div>

      {/* Teams Matchup Row */}
      <div className="grid grid-cols-3 items-center text-center py-2">
        {/* Home Team */}
        <div className="flex flex-col items-center gap-2">
          <TeamLogo
            teamName={nextMatch.homeTeam}
            logoUrl={nextMatch.homeLogo}
            size="lg"
          />
          <div>
            <h4 className="text-xs sm:text-sm font-black text-white">{nextMatch.homeTeam}</h4>
            <span className="text-[10px] text-sky-400 font-semibold uppercase">تیم میزبان</span>
          </div>
        </div>

        {/* VS / Countdown */}
        <div className="flex flex-col items-center justify-center">
          <span className="px-3 py-1 rounded-full bg-blue-600 text-white font-black text-xs sm:text-sm tracking-wider shadow-lg shadow-blue-600/40 font-sports">
            VS
          </span>
          <div className="mt-3 flex items-center justify-center gap-1 sm:gap-1.5 text-center">
            <div className="bg-slate-800/80 px-1.5 py-1 rounded-md min-w-7 border border-slate-700/60">
              <span className="block text-xs sm:text-sm font-black text-white">{timeLeft.days}</span>
              <span className="block text-[8px] text-slate-400">روز</span>
            </div>
            <span className="text-slate-500 font-bold">:</span>
            <div className="bg-slate-800/80 px-1.5 py-1 rounded-md min-w-7 border border-slate-700/60">
              <span className="block text-xs sm:text-sm font-black text-white">{timeLeft.hours}</span>
              <span className="block text-[8px] text-slate-400">ساعت</span>
            </div>
            <span className="text-slate-500 font-bold">:</span>
            <div className="bg-slate-800/80 px-1.5 py-1 rounded-md min-w-7 border border-slate-700/60">
              <span className="block text-xs sm:text-sm font-black text-white">{timeLeft.minutes}</span>
              <span className="block text-[8px] text-slate-400">دقیقه</span>
            </div>
          </div>
        </div>

        {/* Away Team */}
        <div className="flex flex-col items-center gap-2">
          <TeamLogo
            teamName={nextMatch.awayTeam}
            logoUrl={nextMatch.awayLogo}
            size="lg"
          />
          <div>
            <h4 className="text-xs sm:text-sm font-black text-white">{nextMatch.awayTeam}</h4>
            <span className="text-[10px] text-slate-400 font-semibold uppercase">تیم مهمان</span>
          </div>
        </div>
      </div>

      {/* Match Details Footer */}
      <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
        <div className="flex items-center gap-4 flex-wrap">
          <span className="flex items-center gap-1.5">
            <Calendar size={14} className="text-sky-400" />
            <span>{nextMatch.date}</span>
          </span>
          <span className="flex items-center gap-1.5">
            <Clock size={14} className="text-sky-400" />
            <span>ساعت {nextMatch.time}</span>
          </span>
          <span className="flex items-center gap-1.5">
            <MapPin size={14} className="text-sky-400" />
            <span className="truncate max-w-[200px]">{nextMatch.venue}</span>
          </span>
        </div>

        {lastMatch && (
          <div className="text-[11px] bg-slate-800/90 px-2.5 py-1 rounded-lg border border-slate-700/50 flex items-center gap-1.5 text-slate-300">
            <span className="text-slate-400">نتیجه بازی قبل:</span>
            <span className="text-emerald-400 font-bold">برد {lastMatch.awayScore} - {lastMatch.homeScore}</span>
          </div>
        )}
      </div>
    </div>
  );
};
