import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { 
  X, 
  Clock, 
  Eye, 
  Heart, 
  Share2, 
  Tag, 
  User, 
  ChevronRight, 
  ChevronLeft, 
  Film, 
  Trash2, 
  Pin, 
  Sparkles, 
  Check, 
  MessageSquare,
  Send
} from 'lucide-react';

export const NewsModal: React.FC = () => {
  const { 
    selectedNewsId, 
    setSelectedNewsId, 
    news, 
    updateNews, 
    deleteNews, 
    togglePinNews, 
    isAdminLoggedIn,
    setSelectedVideo,
    videos 
  } = useClub();

  const [activeImgIndex, setActiveImgIndex] = useState(0);
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xl'>('normal');
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState<Array<{ name: string; text: string; time: string }>>([
    { name: 'هوادار دو آتیشه اوج', text: 'بهترین نمایش تاکتیکی فصل بود، دست مریزاد به کادر فنی و بچه‌های با غیرت تیم!', time: '۲ ساعت پیش' },
    { name: 'میلاد صادقی', text: 'شماره ۱۰ فوق‌العاده بازی کرد، هت‌تریکش بی‌نظیر بود.', time: '۴ ساعت پیش' }
  ]);

  if (!selectedNewsId) return null;
  const currentNews = news.find(n => n.id === selectedNewsId);
  if (!currentNews) return null;

  const handleLike = () => {
    if (!liked) {
      updateNews(currentNews.id, { likesCount: currentNews.likesCount + 1 });
      setLiked(true);
    } else {
      updateNews(currentNews.id, { likesCount: Math.max(0, currentNews.likesCount - 1) });
      setLiked(false);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: currentNews.title,
          text: currentNews.summary,
          url: window.location.href,
        });
      } catch {
        // user cancelled
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    setComments([
      { name: 'کاربر اپلیکیشن', text: commentText.trim(), time: 'هم‌اکنون' },
      ...comments
    ]);
    setCommentText('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/90 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-blue-600/30 text-sky-400 text-xs font-bold border border-blue-500/30">
              {currentNews.categoryLabel}
            </span>
            {currentNews.isBreaking && (
              <span className="px-2 py-0.5 rounded-md bg-red-600 text-white text-xs font-black animate-pulse">
                خبر فوری
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Font size adjustment */}
            <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700 text-xs">
              <button
                onClick={() => setFontSize('normal')}
                className={`px-2 py-0.5 rounded ${fontSize === 'normal' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
              >
                A
              </button>
              <button
                onClick={() => setFontSize('large')}
                className={`px-2 py-0.5 rounded font-bold ${fontSize === 'large' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
              >
                A+
              </button>
              <button
                onClick={() => setFontSize('xl')}
                className={`px-2 py-0.5 rounded font-black ${fontSize === 'xl' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
              >
                A++
              </button>
            </div>

            {/* Close */}
            <button
              onClick={() => setSelectedNewsId(null)}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* Title */}
          <h1 className="text-lg sm:text-2xl font-black text-white leading-relaxed">
            {currentNews.title}
          </h1>

          {/* Meta bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <User size={14} className="text-slate-500" />
                {currentNews.author}
              </span>
              <span className="flex items-center gap-1">
                <Clock size={14} className="text-slate-500" />
                {currentNews.publishedAt}
              </span>
              <span className="flex items-center gap-1">
                <Eye size={14} className="text-slate-500" />
                {currentNews.viewsCount.toLocaleString('fa-IR')} بازدید
              </span>
            </div>

            {/* Share & Like */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleLike}
                className={`flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  liked 
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30' 
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                <Heart size={14} className={liked ? 'fill-white' : ''} />
                <span>{(currentNews.likesCount + (liked ? 1 : 0)).toLocaleString('fa-IR')}</span>
              </button>

              <button
                onClick={handleShare}
                className="flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
              >
                {copied ? <Check size={14} className="text-emerald-400" /> : <Share2 size={14} />}
                <span>{copied ? 'کپی شد!' : 'اشتراک'}</span>
              </button>
            </div>
          </div>

          {/* Image carousel / viewer */}
          {currentNews.images.length > 0 && (
            <div className="space-y-2">
              <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-800 border border-slate-800">
                <img 
                  src={currentNews.images[activeImgIndex] || currentNews.images[0]} 
                  alt={currentNews.title}
                  className="w-full h-full object-cover"
                />
                {currentNews.images.length > 1 && (
                  <>
                    <button
                      onClick={() => setActiveImgIndex((prev) => (prev > 0 ? prev - 1 : currentNews.images.length - 1))}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-slate-950/60 hover:bg-slate-950/90 text-white backdrop-blur-xs"
                    >
                      <ChevronRight size={18} />
                    </button>
                    <button
                      onClick={() => setActiveImgIndex((prev) => (prev < currentNews.images.length - 1 ? prev + 1 : 0))}
                      className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-slate-950/60 hover:bg-slate-950/90 text-white backdrop-blur-xs"
                    >
                      <ChevronLeft size={18} />
                    </button>
                    <div className="absolute bottom-2 inset-x-0 flex justify-center gap-1.5">
                      {currentNews.images.map((_, idx) => (
                        <button
                          key={idx}
                          onClick={() => setActiveImgIndex(idx)}
                          className={`w-2 h-2 rounded-full transition-all ${
                            activeImgIndex === idx ? 'bg-sky-400 w-5' : 'bg-white/50'
                          }`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* Thumbnails row */}
              {currentNews.images.length > 1 && (
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {currentNews.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImgIndex(idx)}
                      className={`relative w-16 h-12 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                        activeImgIndex === idx ? 'border-sky-400 scale-95' : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Optional Video link */}
          {currentNews.videoUrl && (
            <div className="p-3.5 rounded-xl bg-blue-950/60 border border-blue-600/40 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sky-300 text-xs sm:text-sm font-semibold">
                <Film size={18} className="text-sky-400" />
                <span>ویدیوی اختصاصی ضمیمه این خبر است</span>
              </div>
              <button
                onClick={() => {
                  setSelectedVideo(videos[0] || null);
                  setSelectedNewsId(null);
                }}
                className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors"
              >
                پخش ویدیو
              </button>
            </div>
          )}

          {/* Lead Summary */}
          <div className="p-4 rounded-xl bg-slate-800/60 border-r-4 border-blue-500 text-sm sm:text-base text-slate-200 font-medium leading-relaxed">
            {currentNews.summary}
          </div>

          {/* Body Content */}
          <div className={`space-y-4 text-slate-200 whitespace-pre-line leading-loose ${
            fontSize === 'normal' ? 'text-sm sm:text-base' : fontSize === 'large' ? 'text-base sm:text-lg' : 'text-lg sm:text-xl'
          }`}>
            {currentNews.content}
          </div>

          {/* Tags */}
          {currentNews.tags && currentNews.tags.length > 0 && (
            <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center gap-1.5">
              <Tag size={14} className="text-slate-500" />
              {currentNews.tags.map((tag, idx) => (
                <span 
                  key={idx} 
                  className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 transition-colors"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* Admin Management Shortcuts */}
          {isAdminLoggedIn && (
            <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between gap-2 flex-wrap">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                <Sparkles size={14} />
                ابزارهای مدیریت سریع این خبر:
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => togglePinNews(currentNews.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 ${
                    currentNews.isPinned ? 'bg-amber-500 text-slate-950' : 'bg-slate-700 text-slate-200'
                  }`}
                >
                  <Pin size={12} />
                  {currentNews.isPinned ? 'حذف سنجاق' : 'سنجاق کردن'}
                </button>
                <button
                  onClick={() => {
                    if (confirm('آیا از حذف این خبر اطمینان دارید؟')) {
                      deleteNews(currentNews.id);
                    }
                  }}
                  className="px-2.5 py-1 rounded-lg bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white text-xs font-bold flex items-center gap-1 transition-colors"
                >
                  <Trash2 size={12} />
                  حذف خبر
                </button>
              </div>
            </div>
          )}

          {/* Fan Comments Section */}
          <div className="pt-6 border-t border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <MessageSquare size={16} className="text-sky-400" />
              <span>دیدگاه هواداران ({comments.length.toLocaleString('fa-IR')})</span>
            </div>

            {/* Comment input form */}
            <form onSubmit={handleAddComment} className="flex gap-2">
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="نظر شما درباره این خبر..."
                className="flex-1 bg-slate-800 text-white placeholder-slate-500 text-xs sm:text-sm rounded-xl px-3.5 py-2.5 border border-slate-700 focus:outline-hidden focus:border-blue-500"
              />
              <button
                type="submit"
                className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shrink-0"
              >
                <span>ارسال</span>
                <Send size={14} />
              </button>
            </form>

            {/* Comments list */}
            <div className="space-y-2.5 pt-2">
              {comments.map((c, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 text-right">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                    <span className="font-bold text-sky-400">{c.name}</span>
                    <span>{c.time}</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed">{c.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
