import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Download, 
  Share2, 
  Trash2, 
  Heart, 
  Check, 
  ZoomIn, 
  ZoomOut 
} from 'lucide-react';

export const GalleryViewer: React.FC = () => {
  const { 
    selectedPhotoIndex, 
    setSelectedPhotoIndex, 
    photos, 
    deletePhoto, 
    isAdminLoggedIn 
  } = useClub();

  const [isZoomed, setIsZoomed] = useState(false);
  const [copied, setCopied] = useState(false);

  if (selectedPhotoIndex === null || !photos[selectedPhotoIndex]) return null;

  const currentPhoto = photos[selectedPhotoIndex];

  const handleNext = () => {
    setSelectedPhotoIndex((selectedPhotoIndex + 1) % photos.length);
    setIsZoomed(false);
  };

  const handlePrev = () => {
    setSelectedPhotoIndex(selectedPhotoIndex > 0 ? selectedPhotoIndex - 1 : photos.length - 1);
    setIsZoomed(false);
  };

  const handleDownload = () => {
    // Direct download simulation/fetch
    const link = document.createElement('a');
    link.href = currentPhoto.url;
    link.download = `owj-fc-${currentPhoto.title || 'photo'}.jpg`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: currentPhoto.title,
          text: currentPhoto.caption || 'عکس رسمی تیم فوتبال OWJ',
          url: currentPhoto.url,
        });
      } catch {
        // cancelled
      }
    } else {
      navigator.clipboard.writeText(currentPhoto.url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-lg flex flex-col justify-between">
      {/* Top action bar */}
      <div className="px-4 py-3 bg-gradient-to-b from-black/80 to-transparent flex items-center justify-between text-white z-10">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSelectedPhotoIndex(null)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X size={22} />
          </button>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white truncate max-w-[200px] sm:max-w-md">
              {currentPhoto.title}
            </h3>
            <span className="text-xs text-slate-400">
              {selectedPhotoIndex + 1} از {photos.length}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            onClick={() => setIsZoomed(!isZoomed)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
            title={isZoomed ? 'کوچک‌نمایی' : 'بزرگ‌نمایی'}
          >
            {isZoomed ? <ZoomOut size={18} /> : <ZoomIn size={18} />}
          </button>

          <button
            onClick={handleDownload}
            className="flex items-center gap-1 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors"
            title="دانلود تصویر با کیفیت اصلی"
          >
            <Download size={18} />
            <span className="hidden sm:inline">دانلود</span>
          </button>

          <button
            onClick={handleShare}
            className="flex items-center gap-1 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors"
          >
            {copied ? <Check size={18} className="text-emerald-400" /> : <Share2 size={18} />}
            <span className="hidden sm:inline">{copied ? 'کپی شد' : 'اشتراک'}</span>
          </button>

          {isAdminLoggedIn && (
            <button
              onClick={() => {
                if (confirm('آیا از حذف این تصویر اطمینان دارید؟')) {
                  deletePhoto(currentPhoto.id);
                  setSelectedPhotoIndex(null);
                }
              }}
              className="p-2 rounded-xl bg-red-600/30 hover:bg-red-600 text-red-400 hover:text-white transition-colors"
              title="حذف تصویر"
            >
              <Trash2 size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Main Image Stage */}
      <div className="relative flex-1 flex items-center justify-center p-2 sm:p-6 select-none overflow-hidden">
        <img
          src={currentPhoto.url}
          alt={currentPhoto.title}
          className={`max-h-[82vh] max-w-full object-contain transition-transform duration-300 rounded-lg ${
            isZoomed ? 'scale-150 cursor-grab' : 'scale-100'
          }`}
        />

        {/* Prev / Next controls */}
        <button
          onClick={handlePrev}
          className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/60 hover:bg-black/90 text-white border border-white/20 transition-all hover:scale-110"
        >
          <ChevronRight size={26} />
        </button>
        <button
          onClick={handleNext}
          className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/60 hover:bg-black/90 text-white border border-white/20 transition-all hover:scale-110"
        >
          <ChevronLeft size={26} />
        </button>
      </div>

      {/* Caption footer */}
      {currentPhoto.caption && (
        <div className="p-4 bg-gradient-to-t from-black/90 via-black/60 to-transparent text-center">
          <p className="text-xs sm:text-sm text-slate-200 max-w-2xl mx-auto leading-relaxed">
            {currentPhoto.caption}
          </p>
        </div>
      )}
    </div>
  );
};
