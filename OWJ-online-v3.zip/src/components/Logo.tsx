import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', showText = true, className = '' }) => {
  const sizeMap = {
    sm: { icon: 'w-8 h-8 sm:w-9 sm:h-9', text: 'text-base', sub: 'text-[9px]' },
    md: { icon: 'w-10 h-10 sm:w-11 sm:h-11', text: 'text-xl', sub: 'text-[10px]' },
    lg: { icon: 'w-14 h-14 sm:w-16 sm:h-16', text: 'text-2xl', sub: 'text-xs' },
    xl: { icon: 'w-20 h-20 sm:w-24 sm:h-24', text: 'text-4xl', sub: 'text-sm' },
  };

  const config = sizeMap[size];

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Official OWJ Football Crest Image */}
      <div 
        className={`relative shrink-0 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 via-emerald-400 to-sky-400 shadow-md shadow-blue-600/30 overflow-hidden ${config.icon}`}
      >
        <img
          src="/owj_logo.jpg"
          alt="لوگوی رسمی باشگاه فوتبال OWJ"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover rounded-full bg-slate-950"
        />
      </div>

      {showText && (
        <div className="flex flex-col text-right">
          <div className="flex items-center gap-1.5">
            <span className={`font-black font-sports tracking-wider text-white ${config.text}`}>
              OWJ <span className="text-emerald-400">FC</span>
            </span>
            <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-black bg-gradient-to-r from-blue-600 to-emerald-600 text-white shadow-xs">
              اوج
            </span>
          </div>
          <span className={`text-slate-300 font-medium tracking-tight ${config.sub}`}>
            باشگاه فرهنگی ورزشی اوج
          </span>
        </div>
      )}
    </div>
  );
};
