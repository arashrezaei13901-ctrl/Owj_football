import React, { useState } from 'react';
import { useClub } from '../../context/ClubContext';
import { 
  ShieldCheck, 
  Lock, 
  Plus, 
  Edit3, 
  Trash2, 
  Pin, 
  Sparkles, 
  UploadCloud, 
  Send, 
  Download, 
  RotateCcw, 
  Users, 
  Film, 
  Image as ImageIcon, 
  Newspaper, 
  Trophy, 
  Settings, 
  LogOut, 
  Check, 
  AlertCircle, 
  Layers,
  Calendar,
  Eye,
  Activity,
  Save,
  CheckCircle2,
  FileText,
  Upload,
  X,
  UserPlus,
  Clock3
} from 'lucide-react';
import { Logo } from '../Logo';
import { TeamLogo, PRESET_TEAM_LOGOS } from '../TeamLogo';
import { NewsCategory, Player } from '../../types';

export const AdminDashboard: React.FC = () => {
  const { 
    isAdminLoggedIn, 
    loginAdmin, 
    logoutAdmin,
    news,
    addNews,
    updateNews,
    deleteNews,
    togglePinNews,
    toggleFeaturedNews,
    albums,
    photos,
    addAlbum,
    deleteAlbum,
    addMultiplePhotos,
    deletePhoto,
    videos,
    deleteVideo,
    players,
    addPlayer,
    updatePlayer,
    deletePlayer,
    togglePlayerActive,
    resetPlayerPin,
    pendingPlayerRegistrations,
    approvePendingPlayer,
    rejectPendingPlayer,
    matches,
    addMatch,
    updateMatch,
    deleteMatch,
    sendPushNotification,
    clubInfo,
    updateClubInfo,
    exportBackupJson,
    importBackupJson,
    resetToDefaults,
    setIsUploadModalOpen
  } = useClub();

  // Admin Login State
  const [adminPin, setAdminPin] = useState('');
  const [loginError, setLoginError] = useState('');

  // Admin Active Tab
  type AdminTab = 'overview' | 'news' | 'photos' | 'videos' | 'players' | 'matches' | 'notifications' | 'settings';
  const [activeAdminTab, setActiveAdminTab] = useState<AdminTab>('overview');

  // Sub-forms & states
  // News form
  const [isAddingNews, setIsAddingNews] = useState(false);
  const [newsTitle, setNewsTitle] = useState('');
  const [newsSummary, setNewsSummary] = useState('');
  const [newsContent, setNewsContent] = useState('');
  const [newsCategory, setNewsCategory] = useState<NewsCategory>('team');
  const [newsCategoryLabel, setNewsCategoryLabel] = useState('اخبار تیم');
  const [newsImgUrls, setNewsImgUrls] = useState('');
  const [newsVideoUrl, setNewsVideoUrl] = useState('');
  const [newsIsPinned, setNewsIsPinned] = useState(false);
  const [newsIsFeatured, setNewsIsFeatured] = useState(false);
  const [newsIsBreaking, setNewsIsBreaking] = useState(false);
  const [newsScheduled, setNewsScheduled] = useState(false);
  const [newsScheduleDate, setNewsScheduleDate] = useState('');

  // Photo / Album form
  const [isAddingAlbum, setIsAddingAlbum] = useState(false);
  const [albumTitle, setAlbumTitle] = useState('');
  const [albumCover, setAlbumCover] = useState('');
  const [albumCategory, setAlbumCategory] = useState('مسابقات');

  const [isAddingPhotos, setIsAddingPhotos] = useState(false);
  const [targetAlbumId, setTargetAlbumId] = useState('');
  const [multiPhotoUrls, setMultiPhotoUrls] = useState('');

  // Player form
  const [isAddingPlayer, setIsAddingPlayer] = useState(false);
  const [playerFirstEn, setPlayerFirstEn] = useState('');
  const [playerLastEn, setPlayerLastEn] = useState('');
  const [playerFullFa, setPlayerFullFa] = useState('');
  const [playerIdCode, setPlayerIdCode] = useState('');
  const [playerPin, setPlayerPin] = useState('owjplayer2024');
  const [playerJersey, setPlayerJersey] = useState(11);
  const [playerPosition, setPlayerPosition] = useState<Player['position']>('Forward');
  const [playerPositionFa, setPlayerPositionFa] = useState('مهاجم');
  const [playerPhoto, setPlayerPhoto] = useState('');

  // Push notification form
  const [pushTitle, setPushTitle] = useState('');
  const [pushMessage, setPushMessage] = useState('');
  const [pushCategory, setPushCategory] = useState<'breaking' | 'match' | 'training' | 'media' | 'announcement'>('breaking');
  const [pushPriority, setPushPriority] = useState<'urgent' | 'normal'>('urgent');
  const [pushSentSuccess, setPushSentSuccess] = useState(false);

  // Match form
  const [isAddingMatch, setIsAddingMatch] = useState(false);
  const [matchCompetition, setMatchCompetition] = useState('لیگ برتر فوتبال');
  const [matchHomeTeam, setMatchHomeTeam] = useState('OWJ FC (تیم فوتبال اوج)');
  const [matchAwayTeam, setMatchAwayTeam] = useState('');
  const [matchAwayLogo, setMatchAwayLogo] = useState('');
  const [matchDate, setMatchDate] = useState('۱۴۰۳/۰۷/۰۱');
  const [matchTime, setMatchTime] = useState('۱۸:۰۰');
  const [matchVenue, setMatchVenue] = useState('استادیوم اختصاصی عقاب‌های آبی اوج');

  // Match edit state
  const [editingMatchId, setEditingMatchId] = useState<string | null>(null);
  const [editMatchAwayTeam, setEditMatchAwayTeam] = useState('');
  const [editMatchAwayLogo, setEditMatchAwayLogo] = useState('');
  const [editMatchCompetition, setEditMatchCompetition] = useState('');
  const [editMatchDate, setEditMatchDate] = useState('');
  const [editMatchTime, setEditMatchTime] = useState('');
  const [editMatchVenue, setEditMatchVenue] = useState('');

  // Handle opponent logo upload via file reader
  const handleLogoFileUpload = (e: React.ChangeEvent<HTMLInputElement>, isEditing: boolean = false) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      if (isEditing) {
        setEditMatchAwayLogo(dataUrl);
      } else {
        setMatchAwayLogo(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  // Backup & Restore
  const [backupJsonText, setBackupJsonText] = useState('');
  const [restoreStatus, setRestoreStatus] = useState<'idle' | 'success' | 'error'>('idle');

  // Login handler
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const success = await loginAdmin(adminPin);
    if (!success) setLoginError('رمز عبور مدیر نادرست است.');
  };

  // Submit News
  const handleCreateNews = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsTitle.trim() || !newsContent.trim()) return;

    const urls = newsImgUrls
      .split('\n')
      .map(u => u.trim())
      .filter(u => u.length > 0);

    addNews({
      title: newsTitle.trim(),
      summary: newsSummary.trim() || newsTitle.slice(0, 80) + '...',
      content: newsContent.trim(),
      category: newsCategory,
      categoryLabel: newsCategoryLabel,
      images: urls.length > 0 ? urls : ['https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1200&q=80'],
      videoUrl: newsVideoUrl.trim() || undefined,
      author: 'مدیریت باشگاه OWJ',
      publishedAt: newsScheduled && newsScheduleDate ? newsScheduleDate : new Date().toLocaleDateString('fa-IR'),
      isPinned: newsIsPinned,
      isFeatured: newsIsFeatured,
      isBreaking: newsIsBreaking,
      isScheduled: newsScheduled,
      scheduledFor: newsScheduleDate,
      tags: ['OWJ', 'باشگاه_اوج', newsCategoryLabel]
    });

    // Reset
    setNewsTitle('');
    setNewsSummary('');
    setNewsContent('');
    setNewsImgUrls('');
    setNewsVideoUrl('');
    setNewsIsPinned(false);
    setNewsIsFeatured(false);
    setNewsIsBreaking(false);
    setNewsScheduled(false);
    setIsAddingNews(false);
  };

  // Submit Album
  const handleCreateAlbum = (e: React.FormEvent) => {
    e.preventDefault();
    if (!albumTitle.trim()) return;
    addAlbum({
      title: albumTitle.trim(),
      coverImage: albumCover.trim() || 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=800&q=80',
      category: albumCategory,
      date: new Date().toLocaleDateString('fa-IR')
    });
    setAlbumTitle('');
    setAlbumCover('');
    setIsAddingAlbum(false);
  };

  // Submit Multi Photos
  const handleAddPhotos = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetAlbumId) return;
    const urls = multiPhotoUrls
      .split('\n')
      .map(u => u.trim())
      .filter(u => u.length > 0);
    if (urls.length === 0) return;

    addMultiplePhotos(targetAlbumId, urls);
    setMultiPhotoUrls('');
    setIsAddingPhotos(false);
  };

  // Submit Player
  const handleCreatePlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerFirstEn.trim() || !playerLastEn.trim()) return;

    addPlayer({
      firstNameEn: playerFirstEn.trim(),
      lastNameEn: playerLastEn.trim(),
      fullNameFa: playerFullFa.trim() || `${playerFirstEn} ${playerLastEn}`,
      username: `${playerFirstEn.toLowerCase()}${playerLastEn.toLowerCase()}`,
      playerId: playerIdCode.trim() || `OWJ-${playerJersey}`,
      pinCode: playerPin.trim() || 'owjplayer2024',
      jerseyNumber: playerJersey,
      position: playerPosition,
      positionFa: playerPositionFa,
      photoUrl: playerPhoto.trim() || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=500&q=80',
      age: 23,
      heightCm: 182,
      weightKg: 76,
      preferredFoot: 'راست',
      isActive: true,
      stats: {
        matches: 0,
        goals: 0,
        assists: 0,
        yellowCards: 0,
        redCards: 0,
        minutesPlayed: 0
      },
      attendanceStatus: 'present',
      matchSquadStatus: 'starting'
    });

    setPlayerFirstEn('');
    setPlayerLastEn('');
    setPlayerFullFa('');
    setPlayerIdCode('');
    setPlayerPin('');
    setPlayerPhoto('');
    setIsAddingPlayer(false);
  };

  // Submit Push
  const handleSendPush = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pushTitle.trim() || !pushMessage.trim()) return;

    sendPushNotification(
      pushTitle.trim(),
      pushMessage.trim(),
      pushCategory,
      pushPriority,
      pushCategory === 'breaking' ? 'news' : pushCategory === 'match' ? 'matches' : pushCategory === 'media' ? 'media' : 'players'
    );

    setPushSentSuccess(true);
    setTimeout(() => setPushSentSuccess(false), 3000);
    setPushTitle('');
    setPushMessage('');
  };

  // Submit Match
  const handleCreateMatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!matchAwayTeam.trim()) return;

    addMatch({
      competition: matchCompetition,
      homeTeam: matchHomeTeam,
      awayTeam: matchAwayTeam.trim(),
      homeLogo: 'OWJ',
      awayLogo: matchAwayLogo.trim() || matchAwayTeam.slice(0, 3).toUpperCase(),
      date: matchDate,
      time: matchTime,
      venue: matchVenue,
      status: 'upcoming',
      summary: 'مسابقه رسمی باشگاه فوتبال اوج'
    });

    setMatchAwayTeam('');
    setMatchAwayLogo('');
    setIsAddingMatch(false);
  };

  const handleStartEditMatch = (m: any) => {
    setEditingMatchId(m.id);
    setEditMatchAwayTeam(m.awayTeam || '');
    setEditMatchAwayLogo(m.awayLogo || '');
    setEditMatchCompetition(m.competition || '');
    setEditMatchDate(m.date || '');
    setEditMatchTime(m.time || '');
    setEditMatchVenue(m.venue || '');
  };

  const handleSaveEditMatch = (id: string) => {
    updateMatch(id, {
      competition: editMatchCompetition,
      awayTeam: editMatchAwayTeam,
      awayLogo: editMatchAwayLogo,
      date: editMatchDate,
      time: editMatchTime,
      venue: editMatchVenue
    });
    setEditingMatchId(null);
  };

  // Download Backup
  const handleDownloadBackup = () => {
    const jsonStr = exportBackupJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `owj-fc-backup-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Restore Backup
  const handleRestoreBackup = () => {
    if (!backupJsonText.trim()) return;
    const ok = importBackupJson(backupJsonText.trim());
    if (ok) {
      setRestoreStatus('success');
      setTimeout(() => setRestoreStatus('idle'), 3000);
      setBackupJsonText('');
    } else {
      setRestoreStatus('error');
    }
  };

  // If Admin not logged in: Show Gatekeeper
  if (!isAdminLoggedIn) {
    return (
      <div className="max-w-md mx-auto px-4 py-12">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-center space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-blue-600/20 text-sky-400 flex items-center justify-center mx-auto border border-blue-500/30">
            <Lock size={32} />
          </div>

          <div>
            <h2 className="text-xl font-black text-white">
              ورود به پنل مدیریت تیم فوتبال OWJ
            </h2>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              دسترسی امن فقط برای مدیران رسمی باشگاه • کنترل اخبار، چندرسانه‌ای، بازیکنان و اعلان‌ها
            </p>
          </div>

          <form onSubmit={handleAdminLogin} className="space-y-4 text-right">
            {loginError && (
              <div className="p-3 rounded-xl bg-red-950/70 border border-red-500/50 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle size={15} className="shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                رمز عبور امنیتی مدیریت:
              </label>
              <input
                type="password"
                required
                value={adminPin}
                onChange={(e) => setAdminPin(e.target.value)}
                placeholder="رمز عبور مدیر باشگاه..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-hidden focus:border-blue-500 text-left font-mono"
                dir="ltr"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <ShieldCheck size={18} />
              <span>احراز هویت و ورود</span>
            </button>
          </form>

          {/* Quick Demo Access Button */}
          <div className="pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={() => {
                setAdminPin('owjadmin2024');
                loginAdmin('owjadmin2024');
              }}
              className="w-full py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-sky-400 text-xs font-bold border border-slate-700 transition-colors flex items-center justify-center gap-1.5"
            >
              <Sparkles size={14} />
              <span>ورود سریع آزمایشی (Demo Admin)</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6 space-y-6 pb-24">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-slate-900 to-slate-950 border border-blue-600/30 rounded-2xl p-4 sm:p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-blue-600/30 border border-blue-500/40 text-sky-300">
            <ShieldCheck size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-xl font-black text-white">
                داشبورد مدیریت کل سامانه OWJ FC
              </h1>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                مدیر کل متصل است
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              مدیریت تمام امکانات اپلیکیشن بدون نیاز به ویرایش کد منبع
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={logoutAdmin}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-red-950/60 text-slate-300 hover:text-red-400 border border-slate-700/80 hover:border-red-500/40 text-xs font-bold transition-colors"
          >
            <LogOut size={16} />
            <span>خروج از مدیریت</span>
          </button>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs border-b border-slate-800">
        {[
          { id: 'overview', label: 'داشبورد و آمار', icon: <Activity size={15} /> },
          { id: 'news', label: `اخبار (${news.length})`, icon: <Newspaper size={15} /> },
          { id: 'photos', label: `آلبوم‌ها و تصاویر (${photos.length})`, icon: <ImageIcon size={15} /> },
          { id: 'videos', label: `ویدیوها (${videos.length})`, icon: <Film size={15} /> },
          { id: 'players', label: `بازیکنان (${players.length})`, icon: <Users size={15} /> },
          { id: 'matches', label: `مسابقات (${matches.length})`, icon: <Trophy size={15} /> },
          { id: 'notifications', label: 'ارسال اعلان Push', icon: <Send size={15} /> },
          { id: 'settings', label: 'تنظیمات و بک‌آپ', icon: <Settings size={15} /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveAdminTab(tab.id as AdminTab)}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl font-bold shrink-0 transition-all ${
              activeAdminTab === tab.id
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* 1. OVERVIEW & STATS */}
      {activeAdminTab === 'overview' && (
        <div className="space-y-6">
          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">تعداد کل اخبار منتشرشده</span>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-black text-white font-sports">{news.length}</span>
                <Newspaper size={20} className="text-sky-400" />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">ویدیوهای چندتکه‌ای</span>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-black text-white font-sports">{videos.length}</span>
                <Film size={20} className="text-purple-400" />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">آلبوم و تصاویر رسمی</span>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-black text-white font-sports">{photos.length}</span>
                <ImageIcon size={20} className="text-emerald-400" />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">بازیکنان فعال تیم</span>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-black text-white font-sports">
                  {players.filter(p => p.isActive).length}
                </span>
                <Users size={20} className="text-amber-400" />
              </div>
            </div>
          </div>

          {/* Quick Action Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <button
              onClick={() => {
                setActiveAdminTab('news');
                setIsAddingNews(true);
              }}
              className="p-5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-blue-500/40 text-right space-y-2 transition-all group"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-sky-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Plus size={20} />
              </div>
              <h3 className="text-sm font-bold text-white">انتشار خبر جدید</h3>
              <p className="text-xs text-slate-400">
                افزودن خبر فوری، گزارش مسابقه، عکس‌ها و ویدیوی پیوست
              </p>
            </button>

            <button
              onClick={() => setIsUploadModalOpen(true)}
              className="p-5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-blue-500/40 text-right space-y-2 transition-all group"
            >
              <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <UploadCloud size={20} />
              </div>
              <h3 className="text-sm font-bold text-white">آپلود ویدیوی حجیم تکه‌ای</h3>
              <p className="text-xs text-slate-400">
                ارسال ویدیوی مسابقه با قابلیت Resume و بدون محدودیت حجم
              </p>
            </button>

            <button
              onClick={() => setActiveAdminTab('notifications')}
              className="p-5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-blue-500/40 text-right space-y-2 transition-all group"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-600/20 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Send size={20} />
              </div>
              <h3 className="text-sm font-bold text-white">ارسال اعلان همگانی (Push)</h3>
              <p className="text-xs text-slate-400">
                اطلاع‌رسانی فوری نتیجه بازی یا زمان تمرین به هواداران و بازیکنان
              </p>
            </button>
          </div>
        </div>
      )}

      {/* 2. NEWS MANAGEMENT */}
      {activeAdminTab === 'news' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">مدیریت و انتشار اخبار تیم</h3>
            <button
              onClick={() => setIsAddingNews(!isAddingNews)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md shadow-blue-600/30"
            >
              <Plus size={16} />
              <span>{isAddingNews ? 'بستن فرم' : 'خبر جدید'}</span>
            </button>
          </div>

          {/* New News Form */}
          {isAddingNews && (
            <form onSubmit={handleCreateNews} className="p-5 rounded-2xl bg-slate-900 border border-blue-500/40 space-y-4">
              <h4 className="text-sm font-bold text-sky-400 border-b border-slate-800 pb-2">
                ایجاد و انتشار خبر جدید
              </h4>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">عنوان خبر</label>
                <input
                  type="text"
                  required
                  value={newsTitle}
                  onChange={(e) => setNewsTitle(e.target.value)}
                  placeholder="مثال: برد شیرین در بازی دیروز..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">خلاصه لید خبر</label>
                <textarea
                  rows={2}
                  value={newsSummary}
                  onChange={(e) => setNewsSummary(e.target.value)}
                  placeholder="چکیده کوتاه خبر برای نمایش در صفحه اصلی..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">متن کامل خبر</label>
                <textarea
                  rows={5}
                  required
                  value={newsContent}
                  onChange={(e) => setNewsContent(e.target.value)}
                  placeholder="متن مشروح و پاراگراف‌های خبر..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">دسته‌بندی خبر</label>
                  <select
                    value={newsCategory}
                    onChange={(e) => {
                      const cat = e.target.value as NewsCategory;
                      setNewsCategory(cat);
                      const labels: Record<NewsCategory, string> = {
                        team: 'اخبار تیم',
                        match_report: 'گزارش مسابقه',
                        transfers: 'نقل و انتقالات',
                        interview: 'مصاحبه اختصاصی',
                        training: 'تمرینات',
                        academy: 'آکادمی فوتبال'
                      };
                      setNewsCategoryLabel(labels[cat] || 'اخبار');
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                  >
                    <option value="team">اخبار تیم</option>
                    <option value="match_report">گزارش مسابقه</option>
                    <option value="transfers">نقل و انتقالات</option>
                    <option value="interview">مصاحبه اختصاصی</option>
                    <option value="training">تمرینات</option>
                    <option value="academy">آکادمی فوتبال</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    آدرس ویدیوی پیوست (اختیاری)
                  </label>
                  <input
                    type="url"
                    value={newsVideoUrl}
                    onChange={(e) => setNewsVideoUrl(e.target.value)}
                    placeholder="https://...mp4"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500 text-left"
                    dir="ltr"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  آدرس تصاویر خبر (یک یا چند تصویر در خط‌های مجزا)
                </label>
                <textarea
                  rows={2}
                  value={newsImgUrls}
                  onChange={(e) => setNewsImgUrls(e.target.value)}
                  placeholder="https://images.unsplash.com/...&#10;https://images.unsplash.com/..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500 text-left font-mono"
                  dir="ltr"
                />
              </div>

              {/* Toggles */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-300">
                  <input
                    type="checkbox"
                    checked={newsIsBreaking}
                    onChange={(e) => setNewsIsBreaking(e.target.checked)}
                    className="rounded text-blue-600 w-4 h-4"
                  />
                  <span>خبر فوری (Breaking News)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-300">
                  <input
                    type="checkbox"
                    checked={newsIsFeatured}
                    onChange={(e) => setNewsIsFeatured(e.target.checked)}
                    className="rounded text-blue-600 w-4 h-4"
                  />
                  <span>خبر ویژه صفحه اول</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-300">
                  <input
                    type="checkbox"
                    checked={newsIsPinned}
                    onChange={(e) => setNewsIsPinned(e.target.checked)}
                    className="rounded text-blue-600 w-4 h-4"
                  />
                  <span>سنجاق در بالای لیست (Pin)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-300">
                  <input
                    type="checkbox"
                    checked={newsScheduled}
                    onChange={(e) => setNewsScheduled(e.target.checked)}
                    className="rounded text-blue-600 w-4 h-4"
                  />
                  <span>برنامه‌ریزی انتشار برای آینده</span>
                </label>
              </div>

              {newsScheduled && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    زمان انتشار برنامه‌ریزی‌شده
                  </label>
                  <input
                    type="text"
                    value={newsScheduleDate}
                    onChange={(e) => setNewsScheduleDate(e.target.value)}
                    placeholder="مثلاً: فردا ساعت ۱۲:۰۰"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddingNews(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-bold shadow-md shadow-blue-600/30"
                >
                  انتشار فوری خبر در اپلیکیشن
                </button>
              </div>
            </form>
          )}

          {/* News Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="divide-y divide-slate-800">
              {news.map((item) => (
                <div key={item.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-850">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.images[0]}
                      alt=""
                      className="w-16 h-12 rounded-lg object-cover bg-slate-800 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-600/20 text-sky-400 border border-blue-500/20">
                          {item.categoryLabel}
                        </span>
                        {item.isBreaking && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-red-600 text-white">
                            فوری
                          </span>
                        )}
                        {item.isPinned && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500 text-slate-950 flex items-center gap-0.5">
                            <Pin size={10} /> سنجاق
                          </span>
                        )}
                      </div>
                      <h4 className="text-xs sm:text-sm font-bold text-white truncate max-w-[280px] sm:max-w-md">
                        {item.title}
                      </h4>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        {item.publishedAt} • {item.viewsCount} بازدید
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                    <button
                      onClick={() => togglePinNews(item.id)}
                      className={`p-2 rounded-lg text-xs transition-colors ${
                        item.isPinned ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                      title="سنجاق / عدم سنجاق"
                    >
                      <Pin size={14} />
                    </button>

                    <button
                      onClick={() => toggleFeaturedNews(item.id)}
                      className={`p-2 rounded-lg text-xs transition-colors ${
                        item.isFeatured ? 'bg-blue-600/30 text-sky-300' : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                      title="ویژه / عادی"
                    >
                      <Sparkles size={14} />
                    </button>

                    <button
                      onClick={() => {
                        if (confirm('آیا از حذف این خبر مطمئن هستید؟')) {
                          deleteNews(item.id);
                        }
                      }}
                      className="p-2 rounded-lg bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white transition-colors"
                      title="حذف خبر"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. PHOTOS & ALBUMS */}
      {activeAdminTab === 'photos' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-base font-bold text-white">مدیریت آلبوم‌ها و گالری تصاویر</h3>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsAddingAlbum(!isAddingAlbum)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all"
              >
                <Plus size={14} />
                <span>ایجاد آلبوم جدید</span>
              </button>
              <button
                onClick={() => setIsAddingPhotos(!isAddingPhotos)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all"
              >
                <UploadCloud size={14} />
                <span>آپلود همزمان چند تصویر</span>
              </button>
            </div>
          </div>

          {/* New Album Form */}
          {isAddingAlbum && (
            <form onSubmit={handleCreateAlbum} className="p-4 rounded-2xl bg-slate-900 border border-blue-500/40 space-y-3">
              <h4 className="text-xs sm:text-sm font-bold text-sky-400">ایجاد آلبوم جدید</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 mb-1">عنوان آلبوم</label>
                  <input
                    type="text"
                    required
                    value={albumTitle}
                    onChange={(e) => setAlbumTitle(e.target.value)}
                    placeholder="مثال: عکس‌های تمرینات بدنسازی"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1">تصویر کاور آلبوم</label>
                  <input
                    type="url"
                    value={albumCover}
                    onChange={(e) => setAlbumCover(e.target.value)}
                    placeholder="https://..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white text-left"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1">دسته‌بندی</label>
                  <select
                    value={albumCategory}
                    onChange={(e) => setAlbumCategory(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="مسابقات">مسابقات</option>
                    <option value="تمرینات">تمرینات</option>
                    <option value="پرتره تیمی">پرتره تیمی</option>
                    <option value="هواداران">هواداران</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddingAlbum(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-bold"
                >
                  ذخیره آلبوم
                </button>
              </div>
            </form>
          )}

          {/* Multi Photo Upload Form */}
          {isAddingPhotos && (
            <form onSubmit={handleAddPhotos} className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/40 space-y-3">
              <h4 className="text-xs sm:text-sm font-bold text-emerald-400">آپلود گروهی تصاویر</h4>
              <div>
                <label className="block text-xs text-slate-300 mb-1">انتخاب آلبوم مقصد</label>
                <select
                  required
                  value={targetAlbumId}
                  onChange={(e) => setTargetAlbumId(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                >
                  <option value="">-- لطفاً یک آلبوم را انتخاب کنید --</option>
                  {albums.map((alb) => (
                    <option key={alb.id} value={alb.id}>
                      {alb.title} ({alb.category})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">
                  آدرس‌های تصاویر (هر آدرس در یک خط مجزا)
                </label>
                <textarea
                  rows={3}
                  required
                  value={multiPhotoUrls}
                  onChange={(e) => setMultiPhotoUrls(e.target.value)}
                  placeholder="https://images.unsplash.com/...&#10;https://images.unsplash.com/..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white text-left font-mono"
                  dir="ltr"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddingPhotos(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold"
                >
                  افزودن تصاویر به آلبوم
                </button>
              </div>
            </form>
          )}

          {/* Albums & Photos List */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {albums.map((alb) => (
              <div key={alb.id} className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-800">
                  <img src={alb.coverImage} alt="" className="w-full h-full object-cover" />
                  <span className="absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-900/80 text-sky-400">
                    {alb.category}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h5 className="text-xs font-bold text-white truncate max-w-[160px]">{alb.title}</h5>
                    <span className="text-[10px] text-slate-400">{alb.photosCount} تصویر</span>
                  </div>
                  <button
                    onClick={() => {
                      if (confirm('آیا از حذف این آلبوم و تصاویر آن مطمئن هستید؟')) {
                        deleteAlbum(alb.id);
                      }
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800"
                    title="حذف آلبوم"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. VIDEOS */}
      {activeAdminTab === 'videos' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">مدیریت ویدیوها و پخش آنلاین</h3>
            <button
              onClick={() => setIsUploadModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md shadow-purple-600/30 transition-all"
            >
              <UploadCloud size={16} />
              <span>شروع آپلود تکه‌ای ویدیو</span>
            </button>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="divide-y divide-slate-800">
              {videos.map((v) => (
                <div key={v.id} className="p-4 flex items-center justify-between gap-3 hover:bg-slate-850">
                  <div className="flex items-center gap-3">
                    <img src={v.thumbnailUrl} alt="" className="w-20 aspect-video rounded-lg object-cover bg-slate-800 shrink-0" />
                    <div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-600/20 text-purple-400 border border-purple-500/20">
                        {v.category}
                      </span>
                      <h4 className="text-xs sm:text-sm font-bold text-white mt-1 truncate max-w-[240px] sm:max-w-md">
                        {v.title}
                      </h4>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        حجم: {v.fileSizeMb || 120} مگابایت • مدت: {v.duration}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (confirm('آیا از حذف این ویدیو مطمئن هستید؟')) {
                        deleteVideo(v.id);
                      }
                    }}
                    className="p-2 rounded-lg bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white transition-colors"
                    title="حذف ویدیو"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. PLAYERS MANAGEMENT */}
      {activeAdminTab === 'players' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">مدیریت بازیکنان و لیست تیم</h3>
            <button
              onClick={() => setIsAddingPlayer(!isAddingPlayer)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md shadow-blue-600/30"
            >
              <Plus size={16} />
              <span>{isAddingPlayer ? 'بستن فرم' : 'ثبت بازیکن جدید'}</span>
            </button>
          </div>

          {/* Online pending registrations */}
          {pendingPlayerRegistrations.filter(r => r.status === 'pending').length > 0 && (
            <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-amber-500/15 text-amber-300"><UserPlus size={18} /></div>
                  <div>
                    <h4 className="text-sm font-black text-white">درخواست‌های جدید ثبت‌نام بازیکنان</h4>
                    <p className="text-[11px] text-slate-400">ثبت‌نام‌های آنلاین هر ۵ ثانیه به‌روزرسانی می‌شوند.</p>
                  </div>
                </div>
                <span className="px-2 py-1 rounded-lg bg-amber-500/15 text-amber-300 text-xs font-black">{pendingPlayerRegistrations.filter(r => r.status === 'pending').length} جدید</span>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                {pendingPlayerRegistrations.filter(r => r.status === 'pending').map((r) => (
                  <div key={r.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex flex-col gap-3">
                    <div className="flex items-center gap-3">
                      <img src={r.photoUrl} alt="" className="w-16 h-16 rounded-xl object-cover border border-slate-700" />
                      <div className="min-w-0">
                        <h5 className="text-sm font-bold text-white truncate">{r.fullNameFa}</h5>
                        <p className="text-[11px] text-slate-400 font-mono" dir="ltr">{r.firstNameEn} {r.lastNameEn}</p>
                        <p className="text-[10px] text-amber-400 flex items-center gap-1 mt-1"><Clock3 size={11}/> در انتظار تأیید</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          const jersey = Number(prompt('شماره پیراهن را وارد کنید:', String(r.jerseyNumber || 0)) || 0);
                          const pos = prompt('پست: Forward / Midfielder / Defender / Goalkeeper', r.position || 'Forward') || 'Forward';
                          const result = await approvePendingPlayer(r.id, jersey, pos as Player['position']);
                          if (!result.success) alert(result.message || 'تأیید انجام نشد.');
                          else alert('بازیکن تأیید شد. شناسه و PIN ورود در فهرست بازیکنان نمایش داده می‌شود.');
                        }}
                        className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle2 size={15}/> تأیید و افزودن به تیم
                      </button>
                      <button
                        type="button"
                        onClick={async () => { const result = await rejectPendingPlayer(r.id); if (!result.success) alert(result.message || 'رد درخواست انجام نشد.'); }}
                        className="px-4 py-2 rounded-xl bg-red-600/15 border border-red-500/30 text-red-300 hover:bg-red-600 hover:text-white text-xs font-bold"
                      >رد
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* New Player Form */}
          {isAddingPlayer && (
            <form onSubmit={handleCreatePlayer} className="p-5 rounded-2xl bg-slate-900 border border-blue-500/40 space-y-4">
              <h4 className="text-sm font-bold text-sky-400 border-b border-slate-800 pb-2">
                ثبت بازیکن جدید در کادر تیم
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    نام کوچک به انگلیسی (First Name EN)
                  </label>
                  <input
                    type="text"
                    required
                    value={playerFirstEn}
                    onChange={(e) => setPlayerFirstEn(e.target.value)}
                    placeholder="e.g. Ali"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white text-left font-mono"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    نام خانوادگی به انگلیسی (Last Name EN)
                  </label>
                  <input
                    type="text"
                    required
                    value={playerLastEn}
                    onChange={(e) => setPlayerLastEn(e.target.value)}
                    placeholder="e.g. Rezaei"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white text-left font-mono"
                    dir="ltr"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">نام کامل فارسی</label>
                  <input
                    type="text"
                    value={playerFullFa}
                    onChange={(e) => setPlayerFullFa(e.target.value)}
                    placeholder="مثال: علی رضایی"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    شناسه بازیکن (Player ID)
                  </label>
                  <input
                    type="text"
                    value={playerIdCode}
                    onChange={(e) => setPlayerIdCode(e.target.value)}
                    placeholder="OWJ-10"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white text-left font-mono"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    کد PIN امنیتی برای ورود بازیکن
                  </label>
                  <input
                    type="text"
                    value={playerPin}
                    onChange={(e) => setPlayerPin(e.target.value)}
                    placeholder="owjplayer2024"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white text-left font-mono"
                    dir="ltr"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">شماره پیراهن</label>
                  <input
                    type="number"
                    min={1}
                    max={99}
                    value={playerJersey}
                    onChange={(e) => setPlayerJersey(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white text-left font-mono"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">پست بازیکن</label>
                  <select
                    value={playerPosition}
                    onChange={(e) => {
                      const pos = e.target.value as Player['position'];
                      setPlayerPosition(pos);
                      const map: Record<Player['position'], string> = {
                        Forward: 'مهاجم',
                        Midfielder: 'هافبک',
                        Defender: 'مدافع',
                        Goalkeeper: 'دروازه‌بان'
                      };
                      setPlayerPositionFa(map[pos] || 'بازیکن');
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="Forward">Forward (مهاجم)</option>
                    <option value="Midfielder">Midfielder (هافبک)</option>
                    <option value="Defender">Defender (مدافع)</option>
                    <option value="Goalkeeper">Goalkeeper (دروازه‌بان)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">عکس پرتره بازیکن</label>
                  <input
                    type="url"
                    value={playerPhoto}
                    onChange={(e) => setPlayerPhoto(e.target.value)}
                    placeholder="https://..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white text-left"
                    dir="ltr"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddingPlayer(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold"
                >
                  ثبت بازیکن در سامانه
                </button>
              </div>
            </form>
          )}

          {/* Players Roster Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="divide-y divide-slate-800">
              {players.map((p) => (
                <div key={p.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-850">
                  <div className="flex items-center gap-3">
                    <img src={p.photoUrl} alt="" className="w-12 h-12 rounded-xl object-cover border border-slate-700" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] font-black flex items-center justify-center font-sports">
                          {p.jerseyNumber}
                        </span>
                        <h4 className="text-sm font-bold text-white">{p.fullNameFa}</h4>
                        <span className="text-xs text-slate-400 font-mono" dir="ltr">
                          ({p.firstNameEn} {p.lastNameEn})
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                        <span>شناسه: <strong className="text-sky-400 font-mono" dir="ltr">{p.playerId}</strong></span>
                        <span>•</span>
                        <span>پین ورود: <strong className="text-amber-400 font-mono" dir="ltr">{p.pinCode}</strong></span>
                        <span>•</span>
                        <span>{p.positionFa}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      onClick={() => togglePlayerActive(p.id)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                        p.isActive 
                          ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30' 
                          : 'bg-red-600/20 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {p.isActive ? 'حساب فعال' : 'غیرفعال'}
                    </button>

                    <button
                      onClick={() => {
                        const newPin = prompt('کد PIN جدید را وارد کنید:', p.pinCode);
                        if (newPin && newPin.trim()) {
                          resetPlayerPin(p.id, newPin.trim());
                        }
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium"
                    >
                      ریست PIN
                    </button>

                    <button
                      onClick={() => {
                        if (confirm(`آیا از حذف ${p.fullNameFa} مطمئن هستید؟`)) {
                          deletePlayer(p.id);
                        }
                      }}
                      className="p-1.5 rounded-lg bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white transition-colors"
                      title="حذف بازیکن"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 6. MATCHES */}
      {activeAdminTab === 'matches' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">مدیریت مسابقات و لوگوی تیم‌ها</h3>
              <p className="text-xs text-slate-400 mt-0.5">ثبت مسابقه با نمایش همزمان لوگو و نام تیم حریف</p>
            </div>
            <button
              onClick={() => setIsAddingMatch(!isAddingMatch)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors shadow-md"
            >
              <Plus size={16} />
              <span>{isAddingMatch ? 'بستن' : 'ثبت مسابقه جدید با لوگو'}</span>
            </button>
          </div>

          {isAddingMatch && (
            <form onSubmit={handleCreateMatch} className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-blue-500/40 space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h4 className="text-xs sm:text-sm font-bold text-sky-400">تنظیم اطلاعات بازی جدید و لوگوی تیم حریف</h4>
                <span className="text-[11px] text-slate-400">نام تیم و لوگو همزمان نمایش داده می‌شوند</span>
              </div>

              {/* Tournament & Teams */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 mb-1 font-medium">نام تورنمنت / لیگ</label>
                  <input
                    type="text"
                    required
                    value={matchCompetition}
                    onChange={(e) => setMatchCompetition(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1 font-medium">نام تیم حریف</label>
                  <input
                    type="text"
                    required
                    value={matchAwayTeam}
                    onChange={(e) => setMatchAwayTeam(e.target.value)}
                    placeholder="مثال: پرسپولیس جوان، ملوان، داماش..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Opponent Logo Section */}
              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-amber-400">
                    لوگوی تیم حریف (تصویر لوگو در کنار نام تیم)
                  </label>
                  {matchAwayLogo && (
                    <button
                      type="button"
                      onClick={() => setMatchAwayLogo('')}
                      className="text-[11px] text-red-400 hover:text-red-300 flex items-center gap-1"
                    >
                      <X size={12} />
                      <span>حذف لوگو</span>
                    </button>
                  )}
                </div>

                {/* Live Preview */}
                <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <TeamLogo 
                    teamName={matchAwayTeam || 'تیم حریف'} 
                    logoUrl={matchAwayLogo} 
                    size="md" 
                  />
                  <div>
                    <span className="text-xs font-bold text-white block">
                      {matchAwayTeam || 'نام تیم حریف'}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {matchAwayLogo ? 'لوگوی اختصاصی تنظیم شده است' : 'لوگوی نمادین خودکار بر اساس نام تیم'}
                    </span>
                  </div>
                </div>

                {/* Upload or URL */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  <div>
                    <span className="block text-[11px] text-slate-400 mb-1">روش اول: انتخاب و آپلود عکس لوگو</span>
                    <label className="flex items-center justify-center gap-2 w-full py-2 px-3 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-sky-300 text-xs font-bold cursor-pointer transition-colors">
                      <Upload size={14} />
                      <span>انتخاب فایل لوگو از دستگاه</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleLogoFileUpload(e, false)}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div>
                    <span className="block text-[11px] text-slate-400 mb-1">روش دوم: آدرس اینترنتی تصویر لوگو</span>
                    <input
                      type="url"
                      value={matchAwayLogo}
                      onChange={(e) => setMatchAwayLogo(e.target.value)}
                      placeholder="https://.../logo.png"
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white text-left font-mono focus:outline-hidden focus:border-blue-500"
                      dir="ltr"
                    />
                  </div>
                </div>

                {/* Preset sports crest badges */}
                <div className="pt-2 border-t border-slate-850">
                  <span className="block text-[11px] text-slate-400 mb-1.5">
                    یا انتخاب سریع از میان نشان‌های ورزشی آماده باشگاهی:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_TEAM_LOGOS.map((preset) => {
                      const PresetIcon = preset.icon;
                      const isSelected = matchAwayLogo === preset.id;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => setMatchAwayLogo(preset.id)}
                          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs transition-all border ${
                            isSelected 
                              ? 'bg-blue-600 text-white border-blue-400 font-bold shadow-md' 
                              : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border-slate-700'
                          }`}
                        >
                          <span className={`w-3.5 h-3.5 rounded-full bg-gradient-to-tr ${preset.color} inline-flex items-center justify-center`}>
                            <PresetIcon size={9} className="text-white" />
                          </span>
                          <span className="text-[11px]">{preset.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Venue, Date & Time */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 mb-1 font-medium">ورزشگاه محل برگزاری</label>
                  <input
                    type="text"
                    value={matchVenue}
                    onChange={(e) => setMatchVenue(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1 font-medium">تاریخ بازی</label>
                  <input
                    type="text"
                    value={matchDate}
                    onChange={(e) => setMatchDate(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-300 mb-1 font-medium">ساعت بازی</label>
                  <input
                    type="text"
                    value={matchTime}
                    onChange={(e) => setMatchTime(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddingMatch(false)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 transition-colors"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors shadow-md shadow-blue-600/30"
                >
                  ثبت مسابقه با لوگو و نام
                </button>
              </div>
            </form>
          )}

          {/* Matches List */}
          <div className="space-y-3">
            {matches.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                <p className="text-xs text-slate-400">هنوز مسابقه‌ای ثبت نشده است. با دکمه بالا مسابقه جدید را ثبت کنید.</p>
              </div>
            ) : (
              matches.map((m) => {
                const isEditingThis = editingMatchId === m.id;

                if (isEditingThis) {
                  return (
                    <div key={m.id} className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-amber-500/50 space-y-3 shadow-xl">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                        <span className="text-xs font-bold text-amber-400">ویرایش مسابقه و لوگوی تیم حریف</span>
                        <button
                          type="button"
                          onClick={() => setEditingMatchId(null)}
                          className="text-slate-400 hover:text-white"
                        >
                          <X size={16} />
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs text-slate-300 mb-1">نام تورنمنت</label>
                          <input
                            type="text"
                            value={editMatchCompetition}
                            onChange={(e) => setEditMatchCompetition(e.target.value)}
                            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-xs text-slate-300 mb-1">نام تیم حریف</label>
                          <input
                            type="text"
                            value={editMatchAwayTeam}
                            onChange={(e) => setEditMatchAwayTeam(e.target.value)}
                            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                          />
                        </div>
                      </div>

                      {/* Edit Logo */}
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2.5">
                        <label className="block text-xs font-bold text-sky-400">لوگوی تیم حریف</label>
                        <div className="flex items-center gap-3">
                          <TeamLogo 
                            teamName={editMatchAwayTeam || 'حریف'} 
                            logoUrl={editMatchAwayLogo} 
                            size="md" 
                          />
                          <div className="flex-1 space-y-2">
                            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-sky-300 text-xs font-bold cursor-pointer border border-blue-500/30">
                              <Upload size={13} />
                              <span>آپلود عکس جدید</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleLogoFileUpload(e, true)}
                                className="hidden"
                              />
                            </label>
                            <input
                              type="url"
                              value={editMatchAwayLogo}
                              onChange={(e) => setEditMatchAwayLogo(e.target.value)}
                              placeholder="آدرس اینترنتی لوگو (URL)..."
                              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white text-left font-mono"
                              dir="ltr"
                            />
                          </div>
                        </div>

                        {/* Preset badges */}
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {PRESET_TEAM_LOGOS.map((preset) => (
                            <button
                              key={preset.id}
                              type="button"
                              onClick={() => setEditMatchAwayLogo(preset.id)}
                              className={`px-2 py-0.5 rounded text-[10px] border ${
                                editMatchAwayLogo === preset.id
                                  ? 'bg-blue-600 text-white border-blue-400 font-bold'
                                  : 'bg-slate-800 text-slate-300 border-slate-700'
                              }`}
                            >
                              {preset.name}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                        <input
                          type="text"
                          value={editMatchVenue}
                          onChange={(e) => setEditMatchVenue(e.target.value)}
                          placeholder="ورزشگاه"
                          className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                        />
                        <input
                          type="text"
                          value={editMatchDate}
                          onChange={(e) => setEditMatchDate(e.target.value)}
                          placeholder="تاریخ"
                          className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                        />
                        <input
                          type="text"
                          value={editMatchTime}
                          onChange={(e) => setEditMatchTime(e.target.value)}
                          placeholder="ساعت"
                          className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                        />
                      </div>

                      <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                        <button
                          type="button"
                          onClick={() => setEditingMatchId(null)}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs"
                        >
                          انصراف
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEditMatch(m.id)}
                          className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold"
                        >
                          ذخیره تغییرات لوگو و بازی
                        </button>
                      </div>
                    </div>
                  );
                }

                return (
                  <div key={m.id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-2">
                      <span className="text-[11px] text-sky-400 font-bold block">{m.competition}</span>
                      
                      {/* Teams Matchup with Logos and Names */}
                      <div className="flex items-center gap-3 flex-wrap">
                        {/* Home Team */}
                        <div className="flex items-center gap-2">
                          <TeamLogo teamName={m.homeTeam} logoUrl={m.homeLogo} size="sm" />
                          <span className="text-xs sm:text-sm font-bold text-white">{m.homeTeam}</span>
                        </div>

                        {/* VS or Score */}
                        <span className="px-2.5 py-1 rounded-md bg-slate-950 border border-slate-800 text-sky-400 font-sports font-black text-xs sm:text-sm">
                          {m.status === 'finished' ? `${m.homeScore} - ${m.awayScore}` : 'VS'}
                        </span>

                        {/* Away Team */}
                        <div className="flex items-center gap-2">
                          <TeamLogo teamName={m.awayTeam} logoUrl={m.awayLogo} size="sm" />
                          <span className="text-xs sm:text-sm font-bold text-white">{m.awayTeam}</span>
                        </div>
                      </div>

                      <span className="text-xs text-slate-400 block">
                        {m.date} • ساعت {m.time} • {m.venue}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        onClick={() => handleStartEditMatch(m)}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 flex items-center gap-1 transition-colors"
                      >
                        <Edit3 size={13} className="text-amber-400" />
                        <span>ویرایش لوگو / بازی</span>
                      </button>

                      {m.status === 'upcoming' && (
                        <button
                          onClick={() => {
                            const hScore = prompt('تعداد گل‌های اوج (میزبان):', '2');
                            const aScore = prompt('تعداد گل‌های حریف (مهمان):', '0');
                            if (hScore !== null && aScore !== null) {
                              updateMatch(m.id, {
                                status: 'finished',
                                homeScore: Number(hScore),
                                awayScore: Number(aScore)
                              });
                            }
                          }}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-sky-400 border border-slate-700 transition-colors"
                        >
                          ثبت نتیجه
                        </button>
                      )}

                      <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                        m.status === 'finished' ? 'bg-emerald-600/20 text-emerald-400' : 'bg-blue-600/20 text-sky-400'
                      }`}>
                        {m.status === 'finished' ? 'پایان‌یافته' : 'برگزار نشده'}
                      </span>

                      <button
                        onClick={() => {
                          if (confirm(`آیا از حذف مسابقه با ${m.awayTeam} اطمینان دارید؟`)) {
                            deleteMatch(m.id);
                          }
                        }}
                        className="p-1.5 rounded-lg bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white transition-colors"
                        title="حذف مسابقه"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* 7. NOTIFICATIONS (PUSH) */}
      {activeAdminTab === 'notifications' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl bg-slate-900 border border-blue-500/40 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Send size={18} className="text-sky-400" />
              <h3 className="text-sm sm:text-base font-bold text-white">
                ارسال فوری اعلان Push به گوشی هواداران و اعضای تیم
              </h3>
            </div>

            {pushSentSuccess && (
              <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 size={16} />
                <span>اعلان Push با موفقیت به تمام دستگاه‌ها و تاریخچه اپلیکیشن مخابره شد.</span>
              </div>
            )}

            <form onSubmit={handleSendPush} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  عنوان اعلان (Title)
                </label>
                <input
                  type="text"
                  required
                  value={pushTitle}
                  onChange={(e) => setPushTitle(e.target.value)}
                  placeholder="مثال: ⚽ گل اول تیم اوج به ثمر رسید!"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  متن اعلان (Message Body)
                </label>
                <textarea
                  rows={3}
                  required
                  value={pushMessage}
                  onChange={(e) => setPushMessage(e.target.value)}
                  placeholder="شرح پیام که روی صفحه گوشی ظاهر می‌شود..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">نوع اعلان</label>
                  <select
                    value={pushCategory}
                    onChange={(e) => setPushCategory(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="breaking">خبر فوری (Breaking News)</option>
                    <option value="match">اطلاعات مسابقه و نتیجه</option>
                    <option value="training">برنامه تمرین تیم</option>
                    <option value="media">تصاویر و ویدیوی جدید</option>
                    <option value="announcement">اطلاعیه عمومی باشگاه</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">سطح اولویت</label>
                  <select
                    value={pushPriority}
                    onChange={(e) => setPushPriority(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="urgent">فوری و ارجح (هشدار صدا و لرزش)</option>
                    <option value="normal">عادی</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <Send size={16} />
                <span>مخابره فوری به تمام کاربران و هواداران</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 8. SETTINGS & BACKUP */}
      {activeAdminTab === 'settings' && (
        <div className="space-y-6">
          {/* Club Info Editor */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <Settings size={18} className="text-sky-400" />
              <span>ویرایش مشخصات و هویت تیم فوتبال OWJ</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-300 mb-1">نام رسمی باشگاه</label>
                <input
                  type="text"
                  value={clubInfo.fullName}
                  onChange={(e) => updateClubInfo({ fullName: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">فصل جاری مسابقات</label>
                <input
                  type="text"
                  placeholder="مثال: ۱۴۰۵_۱۴۰۶ یا ۱۴۰۵ - ۱۴۰۶"
                  value={clubInfo.currentSeason || '۱۴۰۵_۱۴۰۶'}
                  onChange={(e) => updateClubInfo({ currentSeason: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">شعار تیم</label>
                <input
                  type="text"
                  value={clubInfo.motto}
                  onChange={(e) => updateClubInfo({ motto: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">سرمربی</label>
                <input
                  type="text"
                  value={clubInfo.headCoach}
                  onChange={(e) => updateClubInfo({ headCoach: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1">استادیوم خانگی</label>
                <input
                  type="text"
                  value={clubInfo.stadium}
                  onChange={(e) => updateClubInfo({ stadium: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
            </div>
          </div>

          {/* Backup & Restore */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <Download size={18} className="text-emerald-400" />
              <span>پشتیبان‌گیری و بازیابی اطلاعات (Backup & Restore)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
                <h4 className="text-xs font-bold text-white">تهیه فایل نسخه پشتیبان</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  از تمام اخبار، تصاویر، ویدیوها، بازیکنان، مسابقات و اعلان‌ها یک نسخه JSON امن دریافت کنید.
                </p>
                <button
                  onClick={handleDownloadBackup}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Download size={14} />
                  <span>دانلود فایل پشتیبان (JSON)</span>
                </button>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
                <h4 className="text-xs font-bold text-white">بازگردانی اطلاعات از فایل</h4>
                <textarea
                  rows={2}
                  value={backupJsonText}
                  onChange={(e) => setBackupJsonText(e.target.value)}
                  placeholder="محتوای JSON نسخه پشتیبان را اینجا جای‌گذاری کنید..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-[11px] text-white font-mono text-left"
                  dir="ltr"
                />
                <button
                  onClick={handleRestoreBackup}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw size={14} />
                  <span>اعمال و بازیابی اطلاعات</span>
                </button>
                {restoreStatus === 'success' && (
                  <span className="text-[11px] text-emerald-400 font-bold block">اطلاعات با موفقیت بازیابی شد.</span>
                )}
                {restoreStatus === 'error' && (
                  <span className="text-[11px] text-red-400 font-bold block">خطا در فرمت فایل JSON پشتیبان.</span>
                )}
              </div>
            </div>

            {/* Reset Factory */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-400">بازنشانی کامل داده‌ها به نمونه اولیه باشگاه:</span>
              <button
                onClick={() => {
                  if (confirm('آیا مایل به بازگردانی تمام اطلاعات به حالت پیش‌فرض اولیه هستید؟')) {
                    resetToDefaults();
                    alert('اطلاعات با موفقیت بازنشانی شد.');
                  }
                }}
                className="px-3 py-1.5 rounded-lg bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white text-xs font-bold transition-colors"
              >
                بازنشانی کارخانه‌ای
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
