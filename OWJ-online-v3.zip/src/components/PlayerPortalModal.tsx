import React, { useRef, useState } from 'react';
import { useClub } from '../context/ClubContext';
import { 
  X, 
  UserCheck, 
  ShieldAlert, 
  Lock, 
  Calendar, 
  Activity, 
  CheckCircle, 
  Clock, 
  LogOut, 
  AlertCircle,
  Trophy,
  Award,
  Sparkles,
  RotateCw,
  Check
} from 'lucide-react';
import { Logo } from './Logo';

export const PlayerPortalModal: React.FC = () => {
  const { 
    isPlayerPortalOpen, 
    setIsPlayerPortalOpen, 
    loggedInPlayer, 
    loginPlayer, 
    logoutPlayer,
    updatePlayerAttendance,
    players,
    registerPlayerOnline
  } = useClub();

  const [firstNameEn, setFirstNameEn] = useState('');
  const [lastNameEn, setLastNameEn] = useState('');
  const [pinOrId, setPinOrId] = useState('owjplayer2024');
  const [errorMsg, setErrorMsg] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [portalMode, setPortalMode] = useState<'login' | 'register'>('login');
  const [regFirstEn, setRegFirstEn] = useState('');
  const [regLastEn, setRegLastEn] = useState('');
  const [regFullFa, setRegFullFa] = useState('');
  const [regJersey, setRegJersey] = useState(0);
  const [regPosition, setRegPosition] = useState<'Goalkeeper' | 'Defender' | 'Midfielder' | 'Forward'>('Forward');
  const [regPhoto, setRegPhoto] = useState<File | null>(null);
  const [regStatus, setRegStatus] = useState('');
  const photoInputRef = useRef<HTMLInputElement | null>(null);

  const handleForceUpdate = async () => {
    setIsUpdating(true);
    try {
      if ('caches' in window) {
        const names = await caches.keys();
        await Promise.all(names.map(name => caches.delete(name)));
      }
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const reg of registrations) {
          await reg.update();
        }
      }
      setUpdateSuccess(true);
      setTimeout(() => {
        window.location.reload();
      }, 700);
    } catch {
      window.location.reload();
    }
  };

  if (!isPlayerPortalOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const res = loginPlayer(firstNameEn, lastNameEn, pinOrId);
    if (!res.success) {
      setErrorMsg(res.message || 'خطا در احراز هویت بازیکن');
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegStatus('');
    if (!regPhoto) { setRegStatus('لطفاً عکس خودتان را انتخاب کنید.'); return; }
    const result = await registerPlayerOnline({
      firstNameEn: regFirstEn.trim(),
      lastNameEn: regLastEn.trim(),
      fullNameFa: regFullFa.trim(),
      jerseyNumber: regJersey,
      position: regPosition,
      photo: regPhoto
    });
    if (result.success) {
      setRegStatus('ثبت‌نام با موفقیت ارسال شد. بعد از تأیید مدیر، نام شما وارد لیست تیم می‌شود.');
      setRegFirstEn(''); setRegLastEn(''); setRegFullFa(''); setRegJersey(0); setRegPhoto(null);
      if (photoInputRef.current) photoInputRef.current.value = '';
    } else {
      setRegStatus(result.message || 'ثبت‌نام انجام نشد.');
    }
  };

  const handleQuickDemo = (playerIdx: number) => {
    const p = players[playerIdx];
    if (p) {
      setFirstNameEn(p.firstNameEn);
      setLastNameEn(p.lastNameEn);
      setPinOrId('owjplayer2024');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-600/20 text-sky-400">
              <UserCheck size={20} />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white">
                پورتال اختصاصی بازیکنان تیم OWJ
              </h3>
              <p className="text-[11px] text-slate-400">
                سیستم داخلی هماهنگی، وضعیت حضور و آمادگی بازیکنان
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsPlayerPortalOpen(false)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-5">
          {loggedInPlayer ? (
            /* Logged in Player View */
            <div className="space-y-5">
              {/* Player Identity Card */}
              <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-900 via-slate-900 to-slate-950 border border-blue-500/40 p-5 shadow-xl">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3.5">
                    <div className="relative">
                      <img 
                        src={loggedInPlayer.photoUrl} 
                        alt={loggedInPlayer.fullNameFa} 
                        className="w-16 h-16 rounded-2xl object-cover border-2 border-sky-400 shadow-md"
                      />
                      <span className="absolute -bottom-1.5 -right-1.5 w-6 h-6 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center border border-slate-900 font-sports">
                        {loggedInPlayer.jerseyNumber}
                      </span>
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5">
                        <h2 className="text-base sm:text-lg font-black text-white">
                          {loggedInPlayer.fullNameFa}
                        </h2>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                          بازیکن فعال
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 font-mono" dir="ltr">
                        {loggedInPlayer.firstNameEn} {loggedInPlayer.lastNameEn} • ID: {loggedInPlayer.playerId}
                      </p>
                      <p className="text-xs text-sky-400 font-semibold mt-0.5">
                        پست: {loggedInPlayer.positionFa} ({loggedInPlayer.position})
                      </p>
                    </div>
                  </div>

                  <Logo size="sm" showText={false} />
                </div>

                {/* Match Squad Status Indicator */}
                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400">وضعیت در مسابقه بعدی:</span>
                  <span className={`px-2.5 py-1 rounded-lg font-bold ${
                    loggedInPlayer.matchSquadStatus === 'starting'
                      ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-600/30 text-amber-300 border border-amber-500/30'
                  }`}>
                    {loggedInPlayer.matchSquadStatus === 'starting' ? '🔥 در ترکیب اصلی (یازده نفر فیکس)' : '⚡ بازیکن تعویضی / ذخیره'}
                  </span>
                </div>
              </div>

              {/* Attendance Toggle for Training */}
              <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                    <Calendar size={16} className="text-sky-400" />
                    <span>اعلام وضعیت حضور در تمرین فردا (ساعت ۹:۳۰)</span>
                  </h4>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => updatePlayerAttendance(loggedInPlayer.id, 'present')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold transition-all border ${
                      loggedInPlayer.attendanceStatus === 'present'
                        ? 'bg-emerald-600 text-white border-emerald-400 shadow-md shadow-emerald-600/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    ✓ اعلام حضور
                  </button>

                  <button
                    onClick={() => updatePlayerAttendance(loggedInPlayer.id, 'injured')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold transition-all border ${
                      loggedInPlayer.attendanceStatus === 'injured'
                        ? 'bg-amber-600 text-white border-amber-400 shadow-md shadow-amber-600/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    🩹 درمان مصدومیت
                  </button>

                  <button
                    onClick={() => updatePlayerAttendance(loggedInPlayer.id, 'excused')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold transition-all border ${
                      loggedInPlayer.attendanceStatus === 'excused'
                        ? 'bg-rose-600 text-white border-rose-400 shadow-md shadow-rose-600/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    ✕ مرخصی موجه
                  </button>
                </div>
              </div>

              {/* Player Season Stats */}
              <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-3">
                <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                  <Activity size={16} className="text-sky-400" />
                  <span>عملکرد فردی در فصل مسابقات</span>
                </h4>

                <div className="grid grid-cols-4 gap-2 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-base sm:text-lg font-black text-white font-sports">
                      {loggedInPlayer.stats.matches}
                    </span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">بازی‌ها</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-base sm:text-lg font-black text-sky-400 font-sports">
                      {loggedInPlayer.stats.goals}
                    </span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">گل‌ها</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-base sm:text-lg font-black text-amber-400 font-sports">
                      {loggedInPlayer.stats.assists}
                    </span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">پاس گل</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-base sm:text-lg font-black text-slate-200 font-sports">
                      {loggedInPlayer.stats.minutesPlayed}
                    </span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">دقایق بازی</span>
                  </div>
                </div>
              </div>

              {/* Coach Confidential Notice */}
              <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-600/30 text-xs text-slate-300 space-y-1">
                <span className="font-bold text-sky-400 block">پیام سرمربی برای جلسه آنالیز:</span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  فیلم بازی حریف فردا در سالن جلسات بررسی می‌شود. لطفاً نیم ساعت قبل از شروع تمرین در سالن ویدیو حضور داشته باشید.
                </p>
              </div>

              {/* App Update / Refresh Section */}
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 flex items-center justify-between gap-2">
                <div>
                  <span className="text-xs font-bold text-white block">بروزرسانی نسخه برنامه</span>
                  <span className="text-[11px] text-slate-400">دریافت آخرین اطلاعات و امکانات</span>
                </div>
                <button
                  type="button"
                  onClick={handleForceUpdate}
                  disabled={isUpdating}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-blue-600/30 disabled:opacity-50"
                >
                  <RotateCw size={13} className={isUpdating ? 'animate-spin' : ''} />
                  <span>{isUpdating ? 'در حال بروزرسانی...' : updateSuccess ? 'بروز شد!' : 'آپدیت نسخه'}</span>
                </button>
              </div>

              {/* Logout */}
              <button
                onClick={logoutPlayer}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-red-950/40 text-slate-300 hover:text-red-400 border border-slate-700/80 hover:border-red-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                <LogOut size={16} />
                <span>خروج از حساب بازیکن</span>
              </button>
            </div>
          ) : (
            /* Login / Registration */
            <>
            <div className="flex p-1 rounded-xl bg-slate-800 border border-slate-700">
              <button type="button" onClick={() => setPortalMode('login')} className={`flex-1 py-2 rounded-lg text-xs font-bold ${portalMode === 'login' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}>ورود بازیکن</button>
              <button type="button" onClick={() => setPortalMode('register')} className={`flex-1 py-2 rounded-lg text-xs font-bold ${portalMode === 'register' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}>ثبت‌نام بازیکن جدید</button>
            </div>
            {portalMode === 'register' ? (
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-500/30 text-[11px] text-slate-300 leading-relaxed">ثبت‌نام شما مستقیماً روی سامانه آنلاین باشگاه ارسال می‌شود و تا تأیید مدیر در وضعیت «در انتظار تأیید» می‌ماند.</div>
                {regStatus && <div className={`p-3 rounded-xl border text-xs ${regStatus.includes('موفقیت') ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' : 'bg-red-950/40 border-red-500/40 text-red-300'}`}>{regStatus}</div>}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input required value={regFirstEn} onChange={e => setRegFirstEn(e.target.value)} placeholder="نام کوچک" className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white" dir="ltr" />
                  <input required value={regLastEn} onChange={e => setRegLastEn(e.target.value)} placeholder="نام خانوادگی" className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white" dir="ltr" />
                </div>
                <input required value={regFullFa} onChange={e => setRegFullFa(e.target.value)} placeholder="نام و نام خانوادگی فارسی" className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white" />
                <div className="grid grid-cols-2 gap-3">
                  <input type="number" min="0" max="99" value={regJersey} onChange={e => setRegJersey(Number(e.target.value))} placeholder="شماره پیراهن" className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white" dir="ltr" />
                  <select value={regPosition} onChange={e => setRegPosition(e.target.value as typeof regPosition)} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white">
                    <option value="Forward">مهاجم</option><option value="Midfielder">هافبک</option><option value="Defender">مدافع</option><option value="Goalkeeper">دروازه‌بان</option>
                  </select>
                </div>
                <label className="block p-4 rounded-xl border border-dashed border-slate-600 bg-slate-800/60 cursor-pointer">
                  <span className="text-xs font-bold text-slate-200 block mb-2">عکس پرتره بازیکن</span>
                  <input ref={photoInputRef} required type="file" accept="image/jpeg,image/png,image/webp" onChange={e => setRegPhoto(e.target.files?.[0] || null)} className="w-full text-xs text-slate-400" />
                  {regPhoto && <span className="text-[10px] text-emerald-400 block mt-2">✓ {regPhoto.name}</span>}
                </label>
                <button type="submit" className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/30">ارسال درخواست ثبت‌نام</button>
              </form>
            ) : (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-500/40 text-xs text-slate-300">
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="font-bold text-sky-400">ورود بازیکنان تیم OWJ</span>
                  <span className="px-2 py-0.5 rounded-md bg-blue-600/40 text-sky-200 font-mono text-xs font-bold border border-blue-400/40" dir="ltr">
                    owjplayer2024
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  رمز عبور ورود بازیکنان به سامانه: <strong className="text-white font-mono" dir="ltr">owjplayer2024</strong> است. نام خود را وارد کرده یا از لیست انتخاب کنید.
                </p>
              </div>

              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/50 text-red-300 text-xs flex items-center gap-2">
                  <AlertCircle size={16} className="shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {players.length > 0 && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    انتخاب مستقیم از لیست بازیکنان تیم
                  </label>
                  <select
                    onChange={(e) => {
                      const p = players.find(item => item.id === e.target.value);
                      if (p) {
                        setFirstNameEn(p.firstNameEn);
                        setLastNameEn(p.lastNameEn);
                        setPinOrId('owjplayer2024');
                      }
                    }}
                    defaultValue=""
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-hidden focus:border-blue-500"
                  >
                    <option value="" disabled>-- انتخاب نام بازیکن --</option>
                    {players.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.fullNameFa} ({p.firstNameEn} {p.lastNameEn}) - شماره {p.jerseyNumber}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  نام کوچک بازیکن (First Name)
                </label>
                <input
                  type="text"
                  required
                  value={firstNameEn}
                  onChange={(e) => setFirstNameEn(e.target.value)}
                  placeholder="e.g. Ali یا علی"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500 text-left font-mono"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  نام خانوادگی بازیکن (Last Name)
                </label>
                <input
                  type="text"
                  required
                  value={lastNameEn}
                  onChange={(e) => setLastNameEn(e.target.value)}
                  placeholder="e.g. Rezaei یا رضایی"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500 text-left font-mono"
                  dir="ltr"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-300">
                    رمز عبور بازیکنان (Password)
                  </label>
                  <span className="text-[11px] text-sky-400 font-mono font-bold" dir="ltr">
                    owjplayer2024
                  </span>
                </div>
                <input
                  type="text"
                  required
                  value={pinOrId}
                  onChange={(e) => setPinOrId(e.target.value)}
                  placeholder="owjplayer2024"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500 text-left font-mono"
                  dir="ltr"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-blue-600/30 flex items-center justify-center gap-1.5 transition-all"
              >
                <Lock size={16} />
                <span>ورود به سامانه بازیکنان</span>
              </button>

              {/* Quick Demo Fillers */}
              <div className="pt-3 border-t border-slate-800">
                <span className="text-[11px] text-slate-400 block mb-2 font-medium">
                  حساب‌های نمونه آزمایشی برای تست سریع:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickDemo(0)}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-right text-xs text-slate-200 transition-colors"
                  >
                    <span className="font-bold block text-sky-400">Ali Rezaei (#10)</span>
                    <span className="text-[10px] text-slate-400 font-mono" dir="ltr">رمز: owjplayer2024</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickDemo(1)}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-right text-xs text-slate-200 transition-colors"
                  >
                    <span className="font-bold block text-sky-400">Kian Moradi (#7)</span>
                    <span className="text-[10px] text-slate-400 font-mono" dir="ltr">رمز: owjplayer2024</span>
                  </button>
                </div>
              </div>

              {/* Version & Force Update Bar */}
              <div className="pt-2 flex items-center justify-between text-xs text-slate-400">
                <span>نسخه اپلیکیشن: ۲.۱.۰</span>
                <button
                  type="button"
                  onClick={handleForceUpdate}
                  disabled={isUpdating}
                  className="flex items-center gap-1.5 text-sky-400 hover:text-sky-300 font-bold transition-colors py-1 px-2 rounded-lg hover:bg-slate-800"
                >
                  <RotateCw size={13} className={isUpdating ? 'animate-spin' : ''} />
                  <span>{isUpdating ? 'در حال آپدیت...' : 'بروزرسانی به آخرین نسخه'}</span>
                </button>
              </div>
            </form>
            )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
