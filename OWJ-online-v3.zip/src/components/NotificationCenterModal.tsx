import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { 
  X, 
  Bell, 
  Zap, 
  Trophy, 
  Calendar, 
  Film, 
  CheckCheck, 
  Trash2, 
  AlertTriangle,
  ChevronLeft,
  BellRing
} from 'lucide-react';
import { PushNotification } from '../types';

export const NotificationCenterModal: React.FC = () => {
  const { 
    isNotificationCenterOpen, 
    setIsNotificationCenterOpen, 
    notifications, 
    markNotificationRead, 
    clearNotifications,
    setCurrentTab,
    setSelectedNewsId
  } = useClub();

  const [filter, setFilter] = useState<'all' | 'breaking' | 'match' | 'training' | 'media'>('all');
  const [permissionState, setPermissionState] = useState<NotificationPermission>(() => {
    return typeof window !== 'undefined' && 'Notification' in window 
      ? Notification.permission 
      : 'default';
  });

  if (!isNotificationCenterOpen) return null;

  const handleRequestPush = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const res = await Notification.requestPermission();
        setPermissionState(res);
        if (res === 'granted') {
          new Notification('باشگاه فوتبال OWJ', {
            body: 'اعلان‌های آنی باشگاه با موفقیت فعال شد. از این پس اخبار فوری را از دست نخواهید داد.',
            icon: '/public/favicon.ico'
          });
        }
      } catch (e) {
        console.warn(e);
      }
    }
  };

  const filtered = notifications.filter(n => filter === 'all' || n.category === filter);

  const getCategoryIcon = (cat: PushNotification['category']) => {
    switch (cat) {
      case 'breaking':
        return <Zap size={15} className="text-red-400 fill-red-400" />;
      case 'match':
        return <Trophy size={15} className="text-amber-400" />;
      case 'training':
        return <Calendar size={15} className="text-emerald-400" />;
      case 'media':
        return <Film size={15} className="text-sky-400" />;
      default:
        return <Bell size={15} className="text-blue-400" />;
    }
  };

  const handleNotifClick = (notif: PushNotification) => {
    markNotificationRead(notif.id);
    if (notif.linkTab) {
      setCurrentTab(notif.linkTab);
      setIsNotificationCenterOpen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-600/20 text-sky-400">
              <Bell size={20} />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white">
                تاریخچه اعلان‌های تیم فوتبال OWJ
              </h3>
              <p className="text-[11px] text-slate-400">
                پیام‌ها، رویدادها و اطلاعیه‌های رسمی باشگاه
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsNotificationCenterOpen(false)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Push Permission Prompt Card */}
          {permissionState !== 'granted' && (
            <div className="p-4 rounded-xl bg-gradient-to-r from-blue-950/80 to-slate-900 border border-blue-500/40 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <BellRing size={20} className="text-sky-400 shrink-0" />
                <div className="text-xs">
                  <span className="font-bold text-white block">فعالسازی Push Notification</span>
                  <span className="text-slate-400 text-[11px]">دریافت گل‌ها و اخبار فوری حتی وقتی اپلیکیشن بسته است</span>
                </div>
              </div>

              <button
                onClick={handleRequestPush}
                className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shrink-0 shadow-md shadow-blue-600/30 transition-all"
              >
                فعالسازی
              </button>
            </div>
          )}

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded-lg font-bold shrink-0 transition-colors ${
                filter === 'all' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              همه ({notifications.length})
            </button>
            <button
              onClick={() => setFilter('breaking')}
              className={`px-3 py-1 rounded-lg font-bold shrink-0 transition-colors ${
                filter === 'breaking' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              اخبار فوری
            </button>
            <button
              onClick={() => setFilter('match')}
              className={`px-3 py-1 rounded-lg font-bold shrink-0 transition-colors ${
                filter === 'match' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              مسابقات
            </button>
            <button
              onClick={() => setFilter('training')}
              className={`px-3 py-1 rounded-lg font-bold shrink-0 transition-colors ${
                filter === 'training' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              تمرینات
            </button>
            <button
              onClick={() => setFilter('media')}
              className={`px-3 py-1 rounded-lg font-bold shrink-0 transition-colors ${
                filter === 'media' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              رسانه و ویدیو
            </button>
          </div>

          {/* Notifications List */}
          <div className="space-y-2.5">
            {filtered.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                هیچ اعلانی در این دسته‌بندی وجود ندارد.
              </div>
            ) : (
              filtered.map((notif) => (
                <div
                  key={notif.id}
                  onClick={() => handleNotifClick(notif)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer group flex items-start gap-3 ${
                    notif.isRead 
                      ? 'bg-slate-800/40 border-slate-800 opacity-80' 
                      : 'bg-slate-800/90 border-blue-500/30 hover:border-blue-500/60 shadow-xs'
                  }`}
                >
                  <div className="p-2 rounded-lg bg-slate-900 shrink-0 border border-slate-700/60">
                    {getCategoryIcon(notif.category)}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-sky-300 transition-colors truncate">
                        {notif.title}
                      </h4>
                      <span className="text-[10px] text-slate-500 shrink-0 font-medium">
                        {notif.createdAt}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                      {notif.message}
                    </p>

                    <div className="mt-2 flex items-center justify-between text-[11px]">
                      {notif.linkTab && (
                        <span className="text-sky-400 font-semibold flex items-center gap-1 group-hover:translate-x-[-2px] transition-transform">
                          مشاهده بخش مربوطه
                          <ChevronLeft size={13} />
                        </span>
                      )}
                      {!notif.isRead && (
                        <span className="w-2 h-2 rounded-full bg-sky-400 mr-auto" />
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Bottom Actions */}
          {notifications.length > 0 && (
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <button
                onClick={() => {
                  notifications.forEach(n => markNotificationRead(n.id));
                }}
                className="flex items-center gap-1 hover:text-white transition-colors"
              >
                <CheckCheck size={15} />
                <span>علامت‌گذاری همه به عنوان خوانده‌شده</span>
              </button>

              <button
                onClick={() => {
                  if (confirm('آیا تمام تاریخچه اعلان‌ها پاک شود؟')) {
                    clearNotifications();
                  }
                }}
                className="flex items-center gap-1 text-red-400/80 hover:text-red-400 transition-colors"
              >
                <Trash2 size={15} />
                <span>پاکسازی تاریخچه</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
