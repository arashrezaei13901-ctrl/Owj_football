import React, { useRef, useState } from 'react';
import { useClub } from '../context/ClubContext';
import { 
  X, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Share2, 
  Eye, 
  Clock, 
  Trash2, 
  Check, 
  Film 
} from 'lucide-react';

export const VideoPlayerModal: React.FC = () => {
  const { selectedVideo, setSelectedVideo, videos, deleteVideo, isAdminLoggedIn } = useClub();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!selectedVideo) return null;

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleFullscreen = () => {
    if (!videoRef.current) return;
    if (videoRef.current.requestFullscreen) {
      videoRef.current.requestFullscreen();
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: selectedVideo.title,
          text: selectedVideo.description,
          url: window.location.href,
        });
      } catch {
        // cancelled
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const related = videos.filter(v => v.id !== selectedVideo.id);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Top bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-md bg-blue-600/30 text-sky-400">
              <Film size={16} />
            </span>
            <span className="text-xs sm:text-sm font-bold text-white truncate max-w-[240px] sm:max-w-md">
              {selectedVideo.title}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
            >
              {copied ? <Check size={14} className="text-emerald-400" /> : <Share2 size={14} />}
              <span className="hidden sm:inline">{copied ? 'کپی شد' : 'اشتراک'}</span>
            </button>

            {isAdminLoggedIn && (
              <button
                onClick={() => {
                  if (confirm('آیا از حذف این ویدیو اطمینان دارید؟')) {
                    deleteVideo(selectedVideo.id);
                    setSelectedVideo(null);
                  }
                }}
                className="p-1.5 rounded-xl bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white transition-colors"
                title="حذف ویدیو توسط مدیر"
              >
                <Trash2 size={16} />
              </button>
            )}

            <button
              onClick={() => setSelectedVideo(null)}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Video Player */}
        <div className="relative aspect-video bg-black flex items-center justify-center group">
          <video
            ref={videoRef}
            src={selectedVideo.videoUrl}
            poster={selectedVideo.thumbnailUrl}
            autoPlay
            controls
            playsInline
            className="w-full h-full object-contain"
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
          />
        </div>

        {/* Details & description */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <span className="inline-block px-2.5 py-0.5 rounded-md bg-blue-600/20 text-sky-400 text-xs font-bold border border-blue-500/20 mb-2">
                {selectedVideo.category}
              </span>
              <h2 className="text-base sm:text-xl font-bold text-white leading-relaxed">
                {selectedVideo.title}
              </h2>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-400">
              <span className="flex items-center gap-1">
                <Clock size={14} className="text-slate-500" />
                مدت: {selectedVideo.duration}
              </span>
              <span className="flex items-center gap-1">
                <Eye size={14} className="text-slate-500" />
                {selectedVideo.viewsCount.toLocaleString('fa-IR')} بازدید
              </span>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {selectedVideo.description}
          </p>

          {/* Related videos list */}
          {related.length > 0 && (
            <div className="pt-4 border-t border-slate-800">
              <h4 className="text-xs sm:text-sm font-bold text-slate-200 mb-3">
                سایر ویدیوهای تیم فوتبال OWJ:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {related.map((v) => (
                  <div
                    key={v.id}
                    onClick={() => setSelectedVideo(v)}
                    className="flex items-center gap-3 p-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 cursor-pointer transition-colors group"
                  >
                    <div className="relative w-24 aspect-video rounded-lg overflow-hidden bg-slate-700 shrink-0">
                      <img src={v.thumbnailUrl} alt={v.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Play size={16} className="text-white fill-white" />
                      </div>
                    </div>
                    <div className="overflow-hidden">
                      <h5 className="text-xs font-bold text-white group-hover:text-sky-400 truncate">
                        {v.title}
                      </h5>
                      <span className="text-[10px] text-slate-400 block mt-1">
                        {v.category} • {v.duration}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
