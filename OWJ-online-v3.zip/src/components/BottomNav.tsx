import React from 'react';
import { useClub } from '../context/ClubContext';
import { AppTab } from '../types';
import { 
  Home, 
  Newspaper, 
  Film, 
  Trophy, 
  Users, 
  ShieldCheck 
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { currentTab, setCurrentTab, isAdminLoggedIn } = useClub();

  const navItems: { id: AppTab; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'خانه', icon: <Home size={20} /> },
    { id: 'news', label: 'اخبار', icon: <Newspaper size={20} /> },
    { id: 'media', label: 'رسانه', icon: <Film size={20} /> },
    { id: 'matches', label: 'مسابقات', icon: <Trophy size={20} /> },
    { id: 'players', label: 'بازیکنان', icon: <Users size={20} /> },
    { id: 'admin', label: 'مدیریت', icon: <ShieldCheck size={20} /> },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 shadow-[0_-4px_20px_rgba(0,0,0,0.4)] pb-safe">
      <div className="max-w-md md:max-w-2xl mx-auto px-2 py-1.5 flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all duration-200 relative ${
                isActive 
                  ? 'text-sky-400 font-bold' 
                  : 'text-slate-400 hover:text-slate-200 font-medium'
              }`}
            >
              <div className={`p-1 rounded-lg transition-transform ${
                isActive ? 'scale-110 bg-blue-600/20 text-sky-400' : ''
              }`}>
                {item.icon}
              </div>
              <span className="text-[11px] mt-0.5 tracking-tight">
                {item.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 bg-sky-400 rounded-full mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
