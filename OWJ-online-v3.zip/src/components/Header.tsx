import React, { useState } from 'react';
import { Logo } from './Logo';
import { useClub } from '../context/ClubContext';
import { 
  Bell, 
  Search, 
  Shield, 
  User, 
  X, 
  ShieldCheck, 
  CheckCircle2, 
  LogOut
} from 'lucide-react';

export const Header: React.FC = () => {
  const { 
    currentTab, 
    setCurrentTab, 
    unreadNotificationsCount, 
    setIsNotificationCenterOpen, 
    isAdminLoggedIn, 
    loggedInPlayer, 
    setIsPlayerPortalOpen,
    searchQuery,
    setSearchQuery
  } = useClub();

  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800/80 shadow-lg">
      {/* Top Brand Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-3">
        {/* Club Crest & Name */}
        <button 
          onClick={() => setCurrentTab('home')}
          className="focus:outline-hidden text-right group flex items-center"
        >
          <Logo size="md" />
        </button>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Search Toggle */}
          <button
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className={`p-2 rounded-xl transition-all ${
              isSearchOpen 
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20' 
                : 'bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white'
            }`}
            title="جستجو در اخبار و رسانه"
          >
            {isSearchOpen ? <X size={18} /> : <Search size={18} />}
          </button>

          {/* Notification Bell with Badge */}
          <button
            onClick={() => setIsNotificationCenterOpen(true)}
            className="relative p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white transition-all active:scale-95"
            title="اعلان‌ها و اخبار فوری"
          >
            <Bell size={18} />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-4.5 h-4.5 px-1 rounded-full bg-red-500 text-white text-[10px] font-black flex items-center justify-center animate-pulse shadow-md shadow-red-500/50">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* Player Portal Button */}
          <button
            onClick={() => setIsPlayerPortalOpen(true)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all active:scale-95 ${
              loggedInPlayer 
                ? 'bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-600/30' 
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
            }`}
            title="پورتال اختصاصی بازیکنان"
          >
            {loggedInPlayer ? (
              <>
                <img 
                  src={loggedInPlayer.photoUrl} 
                  alt={loggedInPlayer.firstNameEn} 
                  className="w-5 h-5 rounded-full object-cover border border-emerald-400"
                />
                <span className="hidden sm:inline">{loggedInPlayer.firstNameEn} ({loggedInPlayer.playerId})</span>
                <span className="sm:hidden text-[10px]">#{loggedInPlayer.jerseyNumber}</span>
              </>
            ) : (
              <>
                <User size={16} className="text-sky-400" />
                <span className="hidden sm:inline">ورود بازیکنان</span>
                <span className="sm:hidden">بازیکن</span>
              </>
            )}
          </button>

          {/* Admin Panel Quick Trigger */}
          <button
            onClick={() => setCurrentTab('admin')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all active:scale-95 ${
              isAdminLoggedIn || currentTab === 'admin'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 ring-1 ring-blue-400' 
                : 'bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60'
            }`}
            title="پنل مدیریت باشگاه"
          >
            {isAdminLoggedIn ? (
              <>
                <ShieldCheck size={16} className="text-amber-300" />
                <span className="hidden md:inline">پنل مدیریت</span>
              </>
            ) : (
              <>
                <Shield size={16} className="text-slate-400" />
                <span className="hidden md:inline">مدیریت</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Expandable Search Drawer */}
      {isSearchOpen && (
        <div className="bg-slate-900 border-t border-slate-800 px-4 py-2.5">
          <div className="max-w-3xl mx-auto relative flex items-center">
            <Search className="absolute right-3 text-slate-400" size={18} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو در عنوان اخبار، ویدیوها، نام بازیکنان و مسابقات..."
              className="w-full bg-slate-800/90 text-white placeholder-slate-400 text-sm rounded-xl py-2 pr-10 pl-10 border border-slate-700/80 focus:outline-hidden focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 text-slate-400 hover:text-white"
              >
                <X size={16} />
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
