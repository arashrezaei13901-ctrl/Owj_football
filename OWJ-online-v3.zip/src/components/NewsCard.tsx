import React from 'react';
import { NewsItem } from '../types';
import { Eye, Clock, Pin, Sparkles, ChevronLeft } from 'lucide-react';
import { useClub } from '../context/ClubContext';

interface NewsCardProps {
  news: NewsItem;
  featured?: boolean;
}

export const NewsCard: React.FC<NewsCardProps> = ({ news, featured = false }) => {
  const { setSelectedNewsId } = useClub();

  if (featured) {
    return (
      <div 
        onClick={() => setSelectedNewsId(news.id)}
        className="group relative cursor-pointer overflow-hidden rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 transition-all duration-300 shadow-lg hover:shadow-blue-600/10 flex flex-col md:flex-row"
      >
        {/* Image */}
        <div className="relative md:w-1/2 aspect-video md:aspect-auto overflow-hidden bg-slate-800">
          <img 
            src={news.images[0] || 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1200&q=80'} 
            alt={news.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-slate-950 via-slate-950/40 to-transparent" />

          {/* Badges */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5 flex-wrap">
            {news.isPinned && (
              <span className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 text-xs font-bold shadow-md">
                <Pin size={12} className="fill-slate-950" />
                سنجاق شده
              </span>
            )}
            {news.isFeatured && (
              <span className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600 text-white text-xs font-bold shadow-md">
                <Sparkles size={12} />
                ویژه باشگاه
              </span>
            )}
            <span className="px-2.5 py-1 rounded-lg bg-slate-900/80 backdrop-blur-xs text-sky-400 text-xs font-bold border border-slate-700">
              {news.categoryLabel}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 md:p-6 md:w-1/2 flex flex-col justify-between">
          <div>
            <h3 className="text-base sm:text-xl font-bold text-white group-hover:text-sky-300 transition-colors line-clamp-2 leading-relaxed">
              {news.title}
            </h3>
            <p className="mt-2 text-xs sm:text-sm text-slate-300 line-clamp-3 leading-relaxed">
              {news.summary}
            </p>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <Clock size={13} className="text-slate-500" />
                {news.publishedAt}
              </span>
              <span className="flex items-center gap-1">
                <Eye size={13} className="text-slate-500" />
                {news.viewsCount.toLocaleString('fa-IR')}
              </span>
            </div>
            <span className="flex items-center gap-1 text-sky-400 font-bold group-hover:translate-x-[-4px] transition-transform">
              ادامه مطلب
              <ChevronLeft size={14} />
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      onClick={() => setSelectedNewsId(news.id)}
      className="group cursor-pointer rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/40 transition-all duration-200 overflow-hidden flex flex-col shadow-md hover:shadow-blue-500/10"
    >
      <div className="relative aspect-video overflow-hidden bg-slate-800">
        <img 
          src={news.images[0]} 
          alt={news.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        <div className="absolute top-2.5 right-2.5 flex items-center gap-1">
          {news.isPinned && (
            <span className="p-1 rounded-md bg-amber-500 text-slate-950 shadow-md">
              <Pin size={11} className="fill-slate-950" />
            </span>
          )}
          <span className="px-2 py-0.5 rounded-md bg-slate-900/85 backdrop-blur-xs text-sky-400 text-[11px] font-bold border border-slate-700">
            {news.categoryLabel}
          </span>
        </div>
      </div>

      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <h4 className="text-sm font-bold text-white group-hover:text-sky-300 transition-colors line-clamp-2 leading-relaxed">
            {news.title}
          </h4>
          <p className="mt-1.5 text-xs text-slate-400 line-clamp-2 leading-relaxed">
            {news.summary}
          </p>
        </div>

        <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <Clock size={12} className="text-slate-500" />
            {news.publishedAt}
          </span>
          <span className="flex items-center gap-1">
            <Eye size={12} className="text-slate-500" />
            {news.viewsCount.toLocaleString('fa-IR')}
          </span>
        </div>
      </div>
    </div>
  );
};
