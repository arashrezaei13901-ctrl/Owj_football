import React, { useState, useEffect } from 'react';
import { useClub } from '../context/ClubContext';
import { Zap, ChevronLeft, Volume2, AlertCircle } from 'lucide-react';

export const BreakingNewsTicker: React.FC = () => {
  const { news, setSelectedNewsId } = useClub();
  const breakingNews = news.filter(n => n.isBreaking || n.isPinned);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (breakingNews.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % breakingNews.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [breakingNews.length]);

  if (breakingNews.length === 0) return null;

  const current = breakingNews[currentIndex] || breakingNews[0];

  return (
    <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-blue-950 border-b border-blue-600/30 overflow-hidden shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2 flex items-center justify-between gap-2 sm:gap-4">
        {/* Flash badge */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-600 text-white font-extrabold text-[11px] sm:text-xs shadow-md shadow-red-600/40 animate-pulse">
            <Zap size={13} className="fill-white" />
            <span>خبر فوری</span>
          </span>
          <span className="hidden sm:inline-block text-[11px] text-blue-300/80 font-medium">
            باشگاه فوتبال OWJ
          </span>
        </div>

        {/* Scrolling / cycling headline */}
        <div 
          onClick={() => setSelectedNewsId(current.id)}
          className="flex-1 cursor-pointer overflow-hidden text-right group"
        >
          <p className="text-xs sm:text-sm text-slate-100 group-hover:text-sky-300 transition-colors font-medium truncate">
            {current.title}
          </p>
        </div>

        {/* Counter & detail indicator */}
        <button
          onClick={() => setSelectedNewsId(current.id)}
          className="shrink-0 flex items-center gap-1 text-[11px] text-blue-400 hover:text-white font-semibold bg-blue-900/40 hover:bg-blue-800/60 px-2 py-1 rounded-lg border border-blue-700/40 transition-colors"
        >
          <span className="hidden xs:inline">مشاهده خبر</span>
          <ChevronLeft size={14} />
        </button>
      </div>
    </div>
  );
};
