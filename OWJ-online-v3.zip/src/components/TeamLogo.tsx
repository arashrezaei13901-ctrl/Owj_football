import React, { useState } from 'react';
import { Shield, Trophy, Flame, Crown, Zap, Star, Award, CircleDot } from 'lucide-react';

export interface TeamLogoProps {
  teamName: string;
  logoUrl?: string;
  isOwj?: boolean;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

// Preset emblem options available for teams
export const PRESET_TEAM_LOGOS = [
  { id: 'preset:shield-red', name: 'سپر قرمز (ستاره)', color: 'from-red-600 to-rose-700', icon: Star, border: 'border-red-500/40' },
  { id: 'preset:shield-blue', name: 'سپر آبی (تاج)', color: 'from-blue-600 to-sky-700', icon: Crown, border: 'border-blue-500/40' },
  { id: 'preset:shield-gold', name: 'سپر طلایی (کاپ)', color: 'from-amber-500 to-yellow-600', icon: Trophy, border: 'border-amber-400/40' },
  { id: 'preset:shield-green', name: 'سپر سبز (نشان)', color: 'from-emerald-600 to-teal-700', icon: Award, border: 'border-emerald-500/40' },
  { id: 'preset:shield-purple', name: 'سپر بنفش (صاعقه)', color: 'from-purple-600 to-indigo-700', icon: Zap, border: 'border-purple-500/40' },
  { id: 'preset:shield-orange', name: 'سپر نارنجی (شعله)', color: 'from-orange-500 to-amber-600', icon: Flame, border: 'border-orange-500/40' },
  { id: 'preset:shield-dark', name: 'سپر مشکی نقره‌ای', color: 'from-slate-700 to-slate-900', icon: Shield, border: 'border-slate-500/40' },
];

export const TeamLogo: React.FC<TeamLogoProps> = ({
  teamName,
  logoUrl,
  isOwj = false,
  size = 'md',
  className = ''
}) => {
  const [hasImageError, setHasImageError] = useState(false);

  // Check if this is the OWJ team
  const isOujTeam = isOwj || 
    teamName.toLowerCase().includes('owj') || 
    teamName.includes('اوج') || 
    logoUrl === 'OWJ';

  const sizeClasses = {
    xs: 'w-6 h-6 text-[10px]',
    sm: 'w-8 h-8 sm:w-9 sm:h-9 text-xs',
    md: 'w-12 h-12 text-sm',
    lg: 'w-16 h-16 sm:w-20 sm:h-20 text-base',
    xl: 'w-20 h-20 sm:w-24 sm:h-24 text-xl',
  };

  const iconSizes = {
    xs: 12,
    sm: 16,
    md: 22,
    lg: 30,
    xl: 40,
  };

  // 1. If OWJ team, show the official OWJ crest
  if (isOujTeam) {
    return (
      <div 
        className={`relative shrink-0 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 via-emerald-400 to-sky-400 shadow-md shadow-blue-600/30 overflow-hidden ${sizeClasses[size]} ${className}`}
        title={teamName}
      >
        <img
          src="/owj_logo.jpg"
          alt={teamName}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover rounded-full bg-slate-950"
        />
      </div>
    );
  }

  // 2. Check if logoUrl is a valid image (URL, Base64, etc.) and hasn't errored
  const isDirectImage = 
    Boolean(logoUrl) && 
    !hasImageError && 
    !logoUrl?.startsWith('preset:') && 
    (logoUrl?.startsWith('http://') || 
     logoUrl?.startsWith('https://') || 
     logoUrl?.startsWith('data:image/') || 
     logoUrl?.startsWith('blob:') || 
     logoUrl?.startsWith('/'));

  if (isDirectImage && logoUrl) {
    return (
      <div 
        className={`relative shrink-0 rounded-2xl bg-slate-900 border border-slate-700/80 p-1 flex items-center justify-center overflow-hidden shadow-md shadow-black/40 ${sizeClasses[size]} ${className}`}
        title={teamName}
      >
        <img
          src={logoUrl}
          alt={teamName}
          referrerPolicy="no-referrer"
          onError={() => setHasImageError(true)}
          className="w-full h-full object-contain rounded-xl"
        />
      </div>
    );
  }

  // 3. Preset emblem or dynamic stylish crest for opponent
  const preset = PRESET_TEAM_LOGOS.find(p => p.id === logoUrl);
  
  // Deterministic color selection based on team name if no preset
  const charCode = (teamName || 'Team').charCodeAt(0) + (teamName || 'Team').charCodeAt((teamName || 'Team').length - 1);
  const fallbackPreset = PRESET_TEAM_LOGOS[charCode % PRESET_TEAM_LOGOS.length];
  const activePreset = preset || fallbackPreset;
  const EmblemIcon = activePreset.icon;

  // Short initial label (first letter or 2 characters)
  const initial = teamName.trim().slice(0, 1) || 'T';

  return (
    <div 
      className={`relative shrink-0 rounded-2xl bg-gradient-to-br ${activePreset.color} border ${activePreset.border} flex flex-col items-center justify-center text-white font-black shadow-md shadow-black/40 overflow-hidden ${sizeClasses[size]} ${className}`}
      title={teamName}
    >
      <div className="absolute inset-0 bg-black/15 pointer-events-none" />
      <EmblemIcon size={iconSizes[size]} className="opacity-90 drop-shadow-sm mb-0.5" />
      {size !== 'xs' && (
        <span className="text-[9px] font-black opacity-95 tracking-tighter leading-none">
          {initial}
        </span>
      )}
    </div>
  );
};
