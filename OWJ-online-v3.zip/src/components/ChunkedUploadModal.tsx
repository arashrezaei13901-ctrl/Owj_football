import React, { useState, useRef } from 'react';
import { useClub } from '../context/ClubContext';
import { 
  X, 
  UploadCloud, 
  Play, 
  Pause, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  Layers, 
  Film, 
  FileVideo, 
  Wifi, 
  WifiOff 
} from 'lucide-react';

export const ChunkedUploadModal: React.FC = () => {
  const { 
    isUploadModalOpen, 
    setIsUploadModalOpen, 
    activeUploads, 
    startChunkedUpload, 
    pauseChunkedUpload, 
    resumeChunkedUpload, 
    cancelChunkedUpload 
  } = useClub();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('خلاصه بازی');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [chunkSizeMb] = useState(5); // 5MB chunks

  if (!isUploadModalOpen) return null;

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    if (!title) {
      setTitle(file.name.replace(/\.[^/.]+$/, ''));
    }
  };

  const handleStartUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;

    const sizeMb = parseFloat((selectedFile.size / (1024 * 1024)).toFixed(2));
    // Calculate chunk count (minimum 5 chunks for visual resumable demonstration)
    const chunksCount = Math.max(8, Math.ceil(sizeMb / chunkSizeMb));

    startChunkedUpload({
      id: `task-${Date.now()}`,
      fileName: selectedFile.name,
      fileSizeMb: sizeMb || 250,
      totalChunks: chunksCount,
      targetCategory: category,
      videoTitle: title.trim() || selectedFile.name,
      videoDescription: description.trim() || 'ویدیوی رسمی باشگاه فوتبال OWJ',
      thumbnailUrl: thumbnailUrl.trim() || 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1000&q=80',
    });

    setSelectedFile(null);
    setTitle('');
    setDescription('');
    setThumbnailUrl('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-600/20 text-sky-400">
              <UploadCloud size={20} />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white">
                سیستم آپلود چندتکه‌ای و قابل ادامه (Resumable Upload)
              </h3>
              <p className="text-[11px] text-slate-400">
                بدون محدودیت مصنوعی حجم فایل • پایداری در نوسانات اینترنت
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsUploadModalOpen(false)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-6">
          {/* Active Upload Tasks (if any) */}
          {activeUploads.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
                <Layers size={14} />
                صف آپلودهای فعال و قابل ادامه:
              </h4>

              {activeUploads.map((task) => (
                <div 
                  key={task.id} 
                  className={`p-4 rounded-xl border transition-all ${
                    task.status === 'completed'
                      ? 'bg-emerald-950/20 border-emerald-500/40'
                      : task.status === 'paused'
                      ? 'bg-amber-950/20 border-amber-500/40'
                      : 'bg-slate-800/80 border-blue-500/40'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <FileVideo size={18} className="text-sky-400 shrink-0" />
                      <div className="overflow-hidden">
                        <span className="text-xs sm:text-sm font-bold text-white block truncate">
                          {task.videoTitle}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          حجم: {task.fileSizeMb} مگابایت • تکه {task.uploadedChunks} از {task.totalChunks}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {task.status === 'uploading' && (
                        <button
                          onClick={() => pauseChunkedUpload(task.id)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-600/30 hover:bg-amber-600 text-amber-300 hover:text-white text-xs font-bold transition-colors"
                          title="توقف موقت آپلود"
                        >
                          <Pause size={12} />
                          <span>توقف</span>
                        </button>
                      )}

                      {task.status === 'paused' && (
                        <button
                          onClick={() => resumeChunkedUpload(task.id)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white text-xs font-bold transition-colors"
                          title="ادامه آپلود از تکه متوقف‌شده"
                        >
                          <Play size={12} />
                          <span>ادامه</span>
                        </button>
                      )}

                      <button
                        onClick={() => cancelChunkedUpload(task.id)}
                        className="p-1 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-red-400 transition-colors"
                        title="لغو آپلود"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden p-0.5 border border-slate-700/60">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        task.status === 'completed'
                          ? 'bg-emerald-500'
                          : task.status === 'paused'
                          ? 'bg-amber-500'
                          : 'bg-gradient-to-r from-blue-600 to-sky-400'
                      }`}
                      style={{ width: `${task.progressPercent}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1.5">
                    <span>
                      {task.status === 'completed' ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle2 size={12} /> آپلود کامل و پردازش شد
                        </span>
                      ) : task.status === 'paused' ? (
                        <span className="text-amber-400 font-medium">آپلود موقتاً متوقف شده است</span>
                      ) : (
                        <span>در حال ارسال تکه‌های فایل به سرور...</span>
                      )}
                    </span>
                    <span className="font-bold text-white font-sports text-xs">
                      {task.progressPercent}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* New Video Upload Form */}
          <form onSubmit={handleStartUpload} className="space-y-4">
            {/* Dropzone */}
            <div
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                  handleFileSelect(e.dataTransfer.files[0]);
                }
              }}
              className="border-2 border-dashed border-slate-700 hover:border-blue-500 rounded-2xl p-6 sm:p-8 text-center cursor-pointer bg-slate-800/30 hover:bg-slate-800/60 transition-all group"
            >
              <input
                type="file"
                ref={fileInputRef}
                accept="video/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileSelect(e.target.files[0]);
                  }
                }}
              />
              <div className="w-12 h-12 rounded-2xl bg-blue-600/20 text-sky-400 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                <Film size={24} />
              </div>
              {selectedFile ? (
                <div>
                  <p className="text-sm font-bold text-sky-400 mb-1 truncate">
                    {selectedFile.name}
                  </p>
                  <p className="text-xs text-slate-400">
                    حجم فایل: {(selectedFile.size / (1024 * 1024)).toFixed(2)} مگابایت (تکه‌بندی خودکار)
                  </p>
                </div>
              ) : (
                <div>
                  <p className="text-xs sm:text-sm font-semibold text-slate-200 mb-1">
                    فایل ویدیویی حجیم را اینجا بکشید یا برای انتخاب کلیک کنید
                  </p>
                  <p className="text-[11px] text-slate-400">
                    پشتیبانی از فرمت‌های MP4, MOV, MKV, WebM با هر حجمی
                  </p>
                </div>
              )}
            </div>

            {/* Video metadata */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  عنوان ویدیو
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثلاً: خلاصه بازی دربی هفته پانزدهم"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  دسته‌بندی ویدیو
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
                >
                  <option value="خلاصه بازی">خلاصه بازی</option>
                  <option value="گل‌ها و مهارت‌ها">گل‌ها و مهارت‌ها</option>
                  <option value="مستند و پشت صحنه">مستند و پشت صحنه</option>
                  <option value="مصاحبه اختصاصی">مصاحبه اختصاصی</option>
                  <option value="تمرینات تاکتیکی">تمرینات تاکتیکی</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                توضیحات ویدیو
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="توضیحات کوتاه درباره محتوای این ویدیو..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                آدرس تصویر بندانگشتی (Thumbnail)
              </label>
              <input
                type="url"
                value={thumbnailUrl}
                onChange={(e) => setThumbnailUrl(e.target.value)}
                placeholder="https://images.unsplash.com/... (اختیاری)"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-blue-500 text-left"
                dir="ltr"
              />
            </div>

            {/* Chunking specs banner */}
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-start gap-2.5 text-slate-300 text-xs">
              <Wifi size={16} className="text-sky-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">مکانیسم آپلود تکه‌ای فعال است</span>
                <span className="text-slate-400 text-[11px] leading-relaxed">
                  فایل به بسته‌های ۵ مگابایتی تقسیم می‌شود. در صورت قطع شبکه یا بستن پنجره، آپلود قابلیت ادامه (Resume) بدون هدر رفتن داده‌ها را خواهد داشت.
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsUploadModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                بستن
              </button>
              <button
                type="submit"
                disabled={!selectedFile}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs sm:text-sm font-bold shadow-lg shadow-blue-600/30 flex items-center gap-1.5 transition-all"
              >
                <UploadCloud size={16} />
                <span>شروع آپلود تکه‌ای</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
