import React from 'react';
import { ClubProvider, useClub } from './context/ClubContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { NewsModal } from './components/NewsModal';
import { GalleryViewer } from './components/GalleryViewer';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { ChunkedUploadModal } from './components/ChunkedUploadModal';
import { PlayerPortalModal } from './components/PlayerPortalModal';
import { NotificationCenterModal } from './components/NotificationCenterModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { HomeView } from './pages/HomeView';
import { NewsView } from './pages/NewsView';
import { MediaView } from './pages/MediaView';
import { PlayersView } from './pages/PlayersView';
import { MatchesView } from './pages/MatchesView';

const MainContent: React.FC = () => {
  const { currentTab } = useClub();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-blue-600 selection:text-white pb-20 md:pb-12">
      {/* Sticky Header */}
      <Header />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 pt-4 sm:pt-6">
        {currentTab === 'home' && <HomeView />}
        {currentTab === 'news' && <NewsView />}
        {currentTab === 'media' && <MediaView />}
        {currentTab === 'players' && <PlayersView />}
        {currentTab === 'matches' && <MatchesView />}
        {currentTab === 'admin' && <AdminDashboard />}
      </main>

      {/* Modals & Overlays */}
      <NewsModal />
      <GalleryViewer />
      <VideoPlayerModal />
      <ChunkedUploadModal />
      <PlayerPortalModal />
      <NotificationCenterModal />

      {/* Mobile-first Bottom Navigation Bar */}
      <BottomNav />
    </div>
  );
};

export default function App() {
  return (
    <ClubProvider>
      <MainContent />
    </ClubProvider>
  );
}
