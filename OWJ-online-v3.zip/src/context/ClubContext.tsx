import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  NewsItem, 
  PhotoAlbum, 
  PhotoItem, 
  VideoItem, 
  Player, 
  MatchItem, 
  TeamStanding, 
  PushNotification, 
  ClubInfo,
  AppTab 
} from '../types';
import {
  fetchOnlinePlayers,
  fetchPendingRegistrations,
  onlineAdminLogin,
  approvePlayerRegistration,
  rejectPlayerRegistration,
  registerPlayerOnline,
  PendingPlayerRegistration
} from '../services/onlineApi';
import { 
  initialNews, 
  initialAlbums, 
  initialPhotos, 
  initialVideos, 
  initialPlayers, 
  initialMatches, 
  initialStandings, 
  initialNotifications, 
  initialClubInfo 
} from '../data/mockData';

interface ChunkedUploadTask {
  id: string;
  fileName: string;
  fileSizeMb: number;
  totalChunks: number;
  uploadedChunks: number;
  progressPercent: number;
  isPaused: boolean;
  status: 'idle' | 'uploading' | 'paused' | 'completed' | 'error';
  targetCategory: string;
  videoTitle: string;
  videoDescription: string;
  thumbnailUrl: string;
}

interface ClubContextType {
  // Navigation & View
  currentTab: AppTab;
  setCurrentTab: (tab: AppTab) => void;
  selectedNewsId: string | null;
  setSelectedNewsId: (id: string | null) => void;
  selectedPhotoIndex: number | null;
  setSelectedPhotoIndex: (idx: number | null) => void;
  selectedVideo: VideoItem | null;
  setSelectedVideo: (v: VideoItem | null) => void;

  // Search & Filter
  searchQuery: string;
  setSearchQuery: (q: string) => void;

  // Club Data
  clubInfo: ClubInfo;
  updateClubInfo: (info: Partial<ClubInfo>) => void;

  // News
  news: NewsItem[];
  addNews: (item: Omit<NewsItem, 'id' | 'viewsCount' | 'likesCount'>) => void;
  updateNews: (id: string, item: Partial<NewsItem>) => void;
  deleteNews: (id: string) => void;
  togglePinNews: (id: string) => void;
  toggleFeaturedNews: (id: string) => void;

  // Media (Photos & Albums)
  albums: PhotoAlbum[];
  photos: PhotoItem[];
  addAlbum: (album: Omit<PhotoAlbum, 'id' | 'photosCount'>) => void;
  deleteAlbum: (id: string) => void;
  addPhoto: (photo: Omit<PhotoItem, 'id' | 'views' | 'likes' | 'uploadedAt'>) => void;
  addMultiplePhotos: (albumId: string, photoUrls: string[], titles?: string[]) => void;
  deletePhoto: (id: string) => void;

  // Videos & Resumable / Chunked Uploads
  videos: VideoItem[];
  addVideo: (video: Omit<VideoItem, 'id' | 'viewsCount' | 'uploadedAt'>) => void;
  updateVideo: (id: string, video: Partial<VideoItem>) => void;
  deleteVideo: (id: string) => void;
  activeUploads: ChunkedUploadTask[];
  startChunkedUpload: (task: Omit<ChunkedUploadTask, 'uploadedChunks' | 'progressPercent' | 'isPaused' | 'status'>) => void;
  pauseChunkedUpload: (taskId: string) => void;
  resumeChunkedUpload: (taskId: string) => void;
  cancelChunkedUpload: (taskId: string) => void;

  // Players & Squad
  players: Player[];
  addPlayer: (player: Omit<Player, 'id'>) => void;
  updatePlayer: (id: string, updates: Partial<Player>) => void;
  deletePlayer: (id: string) => void;
  togglePlayerActive: (id: string) => void;
  resetPlayerPin: (id: string, newPin: string) => void;

  // Matches & Standings
  matches: MatchItem[];
  standings: TeamStanding[];
  addMatch: (match: Omit<MatchItem, 'id'>) => void;
  updateMatch: (id: string, updates: Partial<MatchItem>) => void;
  deleteMatch: (id: string) => void;

  // Push Notifications
  notifications: PushNotification[];
  sendPushNotification: (
    title: string, 
    message: string, 
    category: PushNotification['category'], 
    priority: PushNotification['priority'],
    linkTab?: PushNotification['linkTab']
  ) => void;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
  unreadNotificationsCount: number;

  // Online player registration / administration
  pendingPlayerRegistrations: PendingPlayerRegistration[];
  registerPlayerOnline: (form: { firstNameEn: string; lastNameEn: string; fullNameFa: string; jerseyNumber?: number; position?: Player['position']; photo: File }) => Promise<{ success: boolean; message?: string }>;
  refreshPendingPlayerRegistrations: () => Promise<void>;
  approvePendingPlayer: (id: string, jerseyNumber: number, position: Player['position']) => Promise<{ success: boolean; message?: string }>;
  rejectPendingPlayer: (id: string) => Promise<{ success: boolean; message?: string }>;

  // Authentication
  isAdminLoggedIn: boolean;
  loginAdmin: (pin: string) => Promise<boolean>;
  logoutAdmin: () => void;
  loggedInPlayer: Player | null;
  loginPlayer: (firstNameEn: string, lastNameEn: string, pinOrId: string) => { success: boolean; message?: string };
  logoutPlayer: () => void;
  updatePlayerAttendance: (playerId: string, status: Player['attendanceStatus']) => void;

  // Modals & UI States
  isUploadModalOpen: boolean;
  setIsUploadModalOpen: (open: boolean) => void;
  isPlayerPortalOpen: boolean;
  setIsPlayerPortalOpen: (open: boolean) => void;
  isNotificationCenterOpen: boolean;
  setIsNotificationCenterOpen: (open: boolean) => void;

  // Backup & Reset
  exportBackupJson: () => string;
  importBackupJson: (dataStr: string) => boolean;
  resetToDefaults: () => void;
}

const ClubContext = createContext<ClubContextType | undefined>(undefined);

const ADMIN_DEFAULT_PASS = 'owjadmin2024';
const CLEAN_STORAGE_KEY = 'owj_storage_clean_v1';

// Reset previously cached mock data from localStorage if upgrading to empty app
if (typeof window !== 'undefined') {
  try {
    if (localStorage.getItem(CLEAN_STORAGE_KEY) !== 'true') {
      localStorage.removeItem('owj_news');
      localStorage.removeItem('owj_albums');
      localStorage.removeItem('owj_photos');
      localStorage.removeItem('owj_videos');
      localStorage.removeItem('owj_players');
      localStorage.removeItem('owj_matches');
      localStorage.removeItem('owj_notifications');
      localStorage.removeItem('owj_club_info');
      localStorage.removeItem('owj_player_auth');
      localStorage.setItem(CLEAN_STORAGE_KEY, 'true');
    }
  } catch (e) {
    console.error('Storage reset error', e);
  }
}

export const ClubProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation & Views
  const [currentTab, setCurrentTab] = useState<AppTab>('home');
  const [selectedNewsId, setSelectedNewsId] = useState<string | null>(null);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState<number | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<VideoItem | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isPlayerPortalOpen, setIsPlayerPortalOpen] = useState(false);
  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState(false);

  // Authentication
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => localStorage.getItem('owj_admin_auth') === 'true');
  const [adminToken, setAdminToken] = useState<string>(() => sessionStorage.getItem('owj_admin_token') || '');
  const [pendingPlayerRegistrations, setPendingPlayerRegistrations] = useState<PendingPlayerRegistration[]>([]);

  const [loggedInPlayer, setLoggedInPlayer] = useState<Player | null>(() => {
    const saved = localStorage.getItem('owj_player_auth');
    return saved ? JSON.parse(saved) : null;
  });

  // State with LocalStorage fallbacks
  const [clubInfo, setClubInfo] = useState<ClubInfo>(() => {
    const saved = localStorage.getItem('owj_club_info');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const season = parsed.currentSeason === '۱۴۰۳ - ۱۴۰۴' || parsed.currentSeason === '۱۴۰۵ - ۱۴۰۶' || !parsed.currentSeason
          ? '۱۴۰۵_۱۴۰۶'
          : parsed.currentSeason;
        return { ...initialClubInfo, ...parsed, currentSeason: season };
      } catch {
        return initialClubInfo;
      }
    }
    return initialClubInfo;
  });

  const [news, setNews] = useState<NewsItem[]>(() => {
    const saved = localStorage.getItem('owj_news');
    return saved ? JSON.parse(saved) : initialNews;
  });

  const [albums, setAlbums] = useState<PhotoAlbum[]>(() => {
    const saved = localStorage.getItem('owj_albums');
    return saved ? JSON.parse(saved) : initialAlbums;
  });

  const [photos, setPhotos] = useState<PhotoItem[]>(() => {
    const saved = localStorage.getItem('owj_photos');
    return saved ? JSON.parse(saved) : initialPhotos;
  });

  const [videos, setVideos] = useState<VideoItem[]>(() => {
    const saved = localStorage.getItem('owj_videos');
    return saved ? JSON.parse(saved) : initialVideos;
  });

  const [players, setPlayers] = useState<Player[]>(() => {
    const saved = localStorage.getItem('owj_players');
    return saved ? JSON.parse(saved) : initialPlayers;
  });

  // If the online backend is available, the server becomes the source of truth for the roster.
  useEffect(() => {
    let cancelled = false;
    fetchOnlinePlayers().then(({ players: onlinePlayers }) => {
      if (!cancelled && Array.isArray(onlinePlayers) && onlinePlayers.length) {
        setPlayers(onlinePlayers);
      }
    }).catch(() => { /* local/demo mode */ });
    return () => { cancelled = true; };
  }, []);

  const [matches, setMatches] = useState<MatchItem[]>(() => {
    const saved = localStorage.getItem('owj_matches');
    return saved ? JSON.parse(saved) : initialMatches;
  });

  const [standings] = useState<TeamStanding[]>(initialStandings);

  const [notifications, setNotifications] = useState<PushNotification[]>(() => {
    const saved = localStorage.getItem('owj_notifications');
    return saved ? JSON.parse(saved) : initialNotifications;
  });

  // Resumable Chunked Uploads
  const [activeUploads, setActiveUploads] = useState<ChunkedUploadTask[]>([]);

  // LocalStorage synchronizers
  useEffect(() => {
    localStorage.setItem('owj_club_info', JSON.stringify(clubInfo));
  }, [clubInfo]);

  useEffect(() => {
    localStorage.setItem('owj_news', JSON.stringify(news));
  }, [news]);

  useEffect(() => {
    localStorage.setItem('owj_albums', JSON.stringify(albums));
  }, [albums]);

  useEffect(() => {
    localStorage.setItem('owj_photos', JSON.stringify(photos));
  }, [photos]);

  useEffect(() => {
    localStorage.setItem('owj_videos', JSON.stringify(videos));
  }, [videos]);

  useEffect(() => {
    localStorage.setItem('owj_players', JSON.stringify(players));
  }, [players]);

  useEffect(() => {
    localStorage.setItem('owj_matches', JSON.stringify(matches));
  }, [matches]);

  useEffect(() => {
    localStorage.setItem('owj_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('owj_admin_auth', isAdminLoggedIn ? 'true' : 'false');
  }, [isAdminLoggedIn]);

  useEffect(() => {
    if (loggedInPlayer) {
      localStorage.setItem('owj_player_auth', JSON.stringify(loggedInPlayer));
    } else {
      localStorage.removeItem('owj_player_auth');
    }
  }, [loggedInPlayer]);

  // Handle active chunked uploads interval simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveUploads(prev => {
        let changed = false;
        const next = prev.map(task => {
          if (task.status === 'uploading' && !task.isPaused) {
            changed = true;
            const newUploaded = task.uploadedChunks + 1;
            const progress = Math.min(100, Math.round((newUploaded / task.totalChunks) * 100));
            if (newUploaded >= task.totalChunks) {
              // Complete! Add to videos collection
              setTimeout(() => {
                addVideo({
                  title: task.videoTitle || task.fileName,
                  description: task.videoDescription || 'ویدیوی بارگذاری شده اختصاصی با کیفیت بالا',
                  videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                  thumbnailUrl: task.thumbnailUrl || 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1000&q=80',
                  duration: '۰۵:۳۰',
                  category: task.targetCategory || 'ویدیوهای تیم',
                  isFeatured: false,
                  fileSizeMb: task.fileSizeMb
                });
                sendPushNotification(
                  '🎬 ویدیوی جدید با موفقیت منتشر شد',
                  `ویدیوی "${task.videoTitle || task.fileName}" پردازش و به پلتفرم افزوده شد.`,
                  'media',
                  'normal',
                  'media'
                );
              }, 400);

              return {
                ...task,
                uploadedChunks: task.totalChunks,
                progressPercent: 100,
                status: 'completed' as const
              };
            }
            return {
              ...task,
              uploadedChunks: newUploaded,
              progressPercent: progress
            };
          }
          return task;
        });
        return changed ? next : prev;
      });
    }, 600);

    return () => clearInterval(interval);
  }, [activeUploads]);

  // Admin Auth
  const loginAdmin = async (pin: string): Promise<boolean> => {
    try {
      const { token } = await onlineAdminLogin(pin);
      setAdminToken(token);
      sessionStorage.setItem('owj_admin_token', token);
      setIsAdminLoggedIn(true);
      return true;
    } catch {
      // Keep the original demo fallback so the app can still be previewed locally.
      if (pin === ADMIN_DEFAULT_PASS || pin === '1234' || pin === 'owj2024') {
        setIsAdminLoggedIn(true);
        return true;
      }
      return false;
    }
  };

  const logoutAdmin = () => {
    setIsAdminLoggedIn(false);
    setAdminToken('');
    sessionStorage.removeItem('owj_admin_token');
  };

  const refreshPendingPlayerRegistrations = async () => {
    if (!adminToken) return;
    try {
      const { registrations } = await fetchPendingRegistrations(adminToken);
      setPendingPlayerRegistrations(registrations || []);
    } catch (error) {
      console.error('Failed to load player registrations', error);
    }
  };

  useEffect(() => {
    if (!isAdminLoggedIn || !adminToken) return;
    refreshPendingPlayerRegistrations();
    const timer = window.setInterval(refreshPendingPlayerRegistrations, 5000);
    return () => window.clearInterval(timer);
  }, [isAdminLoggedIn, adminToken]);

  const registerPlayerOnlineAction = async (form: { firstNameEn: string; lastNameEn: string; fullNameFa: string; jerseyNumber?: number; position?: Player['position']; photo: File }) => {
    try {
      await registerPlayerOnline(form);
      return { success: true };
    } catch (error) {
      return { success: false, message: error instanceof Error ? error.message : 'ثبت‌نام انجام نشد.' };
    }
  };

  const approvePendingPlayer = async (id: string, jerseyNumber: number, position: Player['position']) => {
    if (!adminToken) return { success: false, message: 'ابتدا وارد پنل مدیریت شوید.' };
    try {
      const result = await approvePlayerRegistration(adminToken, id, { jerseyNumber, position });
      setPlayers(prev => [...prev.filter(p => p.id !== result.player.id), result.player]);
      await refreshPendingPlayerRegistrations();
      return { success: true };
    } catch (error) {
      return { success: false, message: error instanceof Error ? error.message : 'تأیید انجام نشد.' };
    }
  };

  const rejectPendingPlayer = async (id: string) => {
    if (!adminToken) return { success: false, message: 'ابتدا وارد پنل مدیریت شوید.' };
    try {
      await rejectPlayerRegistration(adminToken, id);
      await refreshPendingPlayerRegistrations();
      return { success: true };
    } catch (error) {
      return { success: false, message: error instanceof Error ? error.message : 'رد درخواست انجام نشد.' };
    }
  };

  // Player Auth
  const loginPlayer = (firstNameEn: string, lastNameEn: string, pinOrId: string) => {
    const cleanFirst = firstNameEn.trim().toLowerCase();
    const cleanLast = lastNameEn.trim().toLowerCase();
    const cleanAuth = pinOrId.trim();
    const isMasterPassword = cleanAuth.toLowerCase() === 'owjplayer2024';

    const matched = players.find(p => {
      // 1. English name match
      const matchEn = p.firstNameEn.toLowerCase() === cleanFirst && p.lastNameEn.toLowerCase() === cleanLast;
      
      // 2. Persian name or full name match
      const fullInput = `${cleanFirst} ${cleanLast}`.trim().toLowerCase();
      const matchFa = 
        p.fullNameFa.trim().toLowerCase() === fullInput ||
        p.fullNameFa.replace(/\s+/g, '') === fullInput.replace(/\s+/g, '') ||
        (cleanFirst && p.fullNameFa.toLowerCase().includes(cleanFirst));

      // 3. Username or ID match
      const matchIdOrUser = 
        (p.username && p.username.toLowerCase() === cleanFirst) ||
        (p.playerId && p.playerId.toLowerCase() === cleanFirst);

      const matchName = matchEn || matchFa || matchIdOrUser;

      // 4. Password / PIN check:
      // Master password 'owjplayer2024' is accepted for ANY registered player
      const matchAuth = 
        isMasterPassword || 
        p.pinCode.toLowerCase() === cleanAuth.toLowerCase() || 
        p.playerId.toUpperCase() === cleanAuth.toUpperCase();

      return matchName && matchAuth;
    });

    if (!matched) {
      return { 
        success: false, 
        message: 'اطلاعات وارد شده صحیح نیست. لطفاً نام بازیکن و رمز عبور (owjplayer2024) را بررسی نمایید.' 
      };
    }

    if (!matched.isActive) {
      return { 
        success: false, 
        message: 'حساب کاربری بازیکن غیرفعال شده است. لطفاً با سرپرست یا مدیر تیم تماس بگیرید.' 
      };
    }

    setLoggedInPlayer(matched);
    return { success: true };
  };

  const logoutPlayer = () => {
    setLoggedInPlayer(null);
  };

  const updatePlayerAttendance = (playerId: string, status: Player['attendanceStatus']) => {
    setPlayers(prev => prev.map(p => p.id === playerId ? { ...p, attendanceStatus: status } : p));
    if (loggedInPlayer && loggedInPlayer.id === playerId) {
      setLoggedInPlayer(prev => prev ? { ...prev, attendanceStatus: status } : null);
    }
  };

  // News Actions
  const addNews = (item: Omit<NewsItem, 'id' | 'viewsCount' | 'likesCount'>) => {
    const newItem: NewsItem = {
      ...item,
      id: `news-${Date.now()}`,
      viewsCount: 1,
      likesCount: 0
    };
    setNews(prev => [newItem, ...prev]);

    // Send push notification if breaking or featured
    if (newItem.isBreaking || newItem.isFeatured) {
      sendPushNotification(
        `🚨 ${newItem.title}`,
        newItem.summary,
        'breaking',
        'urgent',
        'news'
      );
    }
  };

  const updateNews = (id: string, item: Partial<NewsItem>) => {
    setNews(prev => prev.map(n => n.id === id ? { ...n, ...item } : n));
  };

  const deleteNews = (id: string) => {
    setNews(prev => prev.filter(n => n.id !== id));
    if (selectedNewsId === id) setSelectedNewsId(null);
  };

  const togglePinNews = (id: string) => {
    setNews(prev => prev.map(n => n.id === id ? { ...n, isPinned: !n.isPinned } : n));
  };

  const toggleFeaturedNews = (id: string) => {
    setNews(prev => prev.map(n => n.id === id ? { ...n, isFeatured: !n.isFeatured } : n));
  };

  // Media Actions
  const addAlbum = (album: Omit<PhotoAlbum, 'id' | 'photosCount'>) => {
    const newAlb: PhotoAlbum = {
      ...album,
      id: `album-${Date.now()}`,
      photosCount: 0
    };
    setAlbums(prev => [newAlb, ...prev]);
  };

  const deleteAlbum = (id: string) => {
    setAlbums(prev => prev.filter(a => a.id !== id));
    setPhotos(prev => prev.filter(p => p.albumId !== id));
  };

  const addPhoto = (photo: Omit<PhotoItem, 'id' | 'views' | 'likes' | 'uploadedAt'>) => {
    const newP: PhotoItem = {
      ...photo,
      id: `photo-${Date.now()}`,
      views: 0,
      likes: 0,
      uploadedAt: new Date().toLocaleDateString('fa-IR')
    };
    setPhotos(prev => [newP, ...prev]);
    // increment album count
    setAlbums(prev => prev.map(a => a.id === photo.albumId ? { ...a, photosCount: a.photosCount + 1 } : a));
  };

  const addMultiplePhotos = (albumId: string, photoUrls: string[], titles?: string[]) => {
    const newPhotos: PhotoItem[] = photoUrls.map((url, idx) => ({
      id: `photo-${Date.now()}-${idx}`,
      albumId,
      title: (titles && titles[idx]) || `تصویر شماره ${idx + 1}`,
      url,
      views: 0,
      likes: 0,
      uploadedAt: new Date().toLocaleDateString('fa-IR')
    }));
    setPhotos(prev => [...newPhotos, ...prev]);
    setAlbums(prev => prev.map(a => a.id === albumId ? { ...a, photosCount: a.photosCount + newPhotos.length } : a));
  };

  const deletePhoto = (id: string) => {
    const target = photos.find(p => p.id === id);
    if (target) {
      setAlbums(prev => prev.map(a => a.id === target.albumId ? { ...a, photosCount: Math.max(0, a.photosCount - 1) } : a));
    }
    setPhotos(prev => prev.filter(p => p.id !== id));
  };

  // Video Actions
  const addVideo = (video: Omit<VideoItem, 'id' | 'viewsCount' | 'uploadedAt'>) => {
    const newVid: VideoItem = {
      ...video,
      id: `vid-${Date.now()}`,
      viewsCount: 0,
      uploadedAt: new Date().toLocaleDateString('fa-IR')
    };
    setVideos(prev => [newVid, ...prev]);
  };

  const updateVideo = (id: string, video: Partial<VideoItem>) => {
    setVideos(prev => prev.map(v => v.id === id ? { ...v, ...video } : v));
  };

  const deleteVideo = (id: string) => {
    setVideos(prev => prev.filter(v => v.id !== id));
  };

  // Resumable / Chunked Upload implementation
  const startChunkedUpload = (task: Omit<ChunkedUploadTask, 'uploadedChunks' | 'progressPercent' | 'isPaused' | 'status'>) => {
    const newTask: ChunkedUploadTask = {
      ...task,
      uploadedChunks: 0,
      progressPercent: 0,
      isPaused: false,
      status: 'uploading'
    };
    setActiveUploads(prev => [newTask, ...prev.filter(u => u.id !== task.id)]);
  };

  const pauseChunkedUpload = (taskId: string) => {
    setActiveUploads(prev => prev.map(u => u.id === taskId ? { ...u, isPaused: true, status: 'paused' } : u));
  };

  const resumeChunkedUpload = (taskId: string) => {
    setActiveUploads(prev => prev.map(u => u.id === taskId ? { ...u, isPaused: false, status: 'uploading' } : u));
  };

  const cancelChunkedUpload = (taskId: string) => {
    setActiveUploads(prev => prev.filter(u => u.id !== taskId));
  };

  // Player Actions
  const addPlayer = (player: Omit<Player, 'id'>) => {
    const newP: Player = {
      ...player,
      id: `p-${Date.now()}`
    };
    setPlayers(prev => [...prev, newP]);
  };

  const updatePlayer = (id: string, updates: Partial<Player>) => {
    setPlayers(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const deletePlayer = (id: string) => {
    setPlayers(prev => prev.filter(p => p.id !== id));
  };

  const togglePlayerActive = (id: string) => {
    setPlayers(prev => prev.map(p => p.id === id ? { ...p, isActive: !p.isActive } : p));
  };

  const resetPlayerPin = (id: string, newPin: string) => {
    setPlayers(prev => prev.map(p => p.id === id ? { ...p, pinCode: newPin } : p));
  };

  // Matches Actions
  const addMatch = (match: Omit<MatchItem, 'id'>) => {
    const newM: MatchItem = {
      ...match,
      id: `match-${Date.now()}`
    };
    setMatches(prev => [newM, ...prev]);
  };

  const updateMatch = (id: string, updates: Partial<MatchItem>) => {
    setMatches(prev => prev.map(m => m.id === id ? { ...m, ...updates } : m));
  };

  const deleteMatch = (id: string) => {
    setMatches(prev => prev.filter(m => m.id !== id));
  };

  // Push Notifications
  const sendPushNotification = (
    title: string, 
    message: string, 
    category: PushNotification['category'], 
    priority: PushNotification['priority'] = 'normal',
    linkTab?: PushNotification['linkTab']
  ) => {
    const newNotif: PushNotification = {
      id: `notif-${Date.now()}`,
      title,
      message,
      category,
      priority,
      createdAt: 'هم‌اکنون',
      isRead: false,
      linkTab
    };
    setNotifications(prev => [newNotif, ...prev]);

    // Trigger Native Web Notification if permission granted
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        try {
          new Notification(title, {
            body: message,
            icon: '/public/favicon.ico'
          });
        } catch {
          // ignore inside sandbox
        }
      }
    }
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  const unreadNotificationsCount = notifications.filter(n => !n.isRead).length;

  const updateClubInfo = (info: Partial<ClubInfo>) => {
    setClubInfo(prev => ({ ...prev, ...info }));
  };

  // Backup & Restore
  const exportBackupJson = () => {
    const payload = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      clubInfo,
      news,
      albums,
      photos,
      videos,
      players,
      matches,
      notifications
    };
    return JSON.stringify(payload, null, 2);
  };

  const importBackupJson = (dataStr: string): boolean => {
    try {
      const data = JSON.parse(dataStr);
      if (data.news && Array.isArray(data.news)) setNews(data.news);
      if (data.albums && Array.isArray(data.albums)) setAlbums(data.albums);
      if (data.photos && Array.isArray(data.photos)) setPhotos(data.photos);
      if (data.videos && Array.isArray(data.videos)) setVideos(data.videos);
      if (data.players && Array.isArray(data.players)) setPlayers(data.players);
      if (data.matches && Array.isArray(data.matches)) setMatches(data.matches);
      if (data.clubInfo) setClubInfo(data.clubInfo);
      if (data.notifications && Array.isArray(data.notifications)) setNotifications(data.notifications);
      return true;
    } catch (e) {
      console.error('Failed to parse backup JSON', e);
      return false;
    }
  };

  const resetToDefaults = () => {
    setNews(initialNews);
    setAlbums(initialAlbums);
    setPhotos(initialPhotos);
    setVideos(initialVideos);
    setPlayers(initialPlayers);
    setMatches(initialMatches);
    setClubInfo(initialClubInfo);
    setNotifications(initialNotifications);
  };

  return (
    <ClubContext.Provider
      value={{
        currentTab,
        setCurrentTab,
        selectedNewsId,
        setSelectedNewsId,
        selectedPhotoIndex,
        setSelectedPhotoIndex,
        selectedVideo,
        setSelectedVideo,
        searchQuery,
        setSearchQuery,
        clubInfo,
        updateClubInfo,
        news,
        addNews,
        updateNews,
        deleteNews,
        togglePinNews,
        toggleFeaturedNews,
        albums,
        photos,
        addAlbum,
        deleteAlbum,
        addPhoto,
        addMultiplePhotos,
        deletePhoto,
        videos,
        addVideo,
        updateVideo,
        deleteVideo,
        activeUploads,
        startChunkedUpload,
        pauseChunkedUpload,
        resumeChunkedUpload,
        cancelChunkedUpload,
        players,
        addPlayer,
        updatePlayer,
        deletePlayer,
        togglePlayerActive,
        resetPlayerPin,
        pendingPlayerRegistrations,
        registerPlayerOnline: registerPlayerOnlineAction,
        refreshPendingPlayerRegistrations,
        approvePendingPlayer,
        rejectPendingPlayer,
        matches,
        standings,
        addMatch,
        updateMatch,
        deleteMatch,
        notifications,
        sendPushNotification,
        markNotificationRead,
        clearNotifications,
        unreadNotificationsCount,
        isAdminLoggedIn,
        loginAdmin,
        logoutAdmin,
        loggedInPlayer,
        loginPlayer,
        logoutPlayer,
        updatePlayerAttendance,
        isUploadModalOpen,
        setIsUploadModalOpen,
        isPlayerPortalOpen,
        setIsPlayerPortalOpen,
        isNotificationCenterOpen,
        setIsNotificationCenterOpen,
        exportBackupJson,
        importBackupJson,
        resetToDefaults
      }}
    >
      {children}
    </ClubContext.Provider>
  );
};

export const useClub = () => {
  const context = useContext(ClubContext);
  if (!context) {
    throw new Error('useClub must be used within a ClubProvider');
  }
  return context;
};
