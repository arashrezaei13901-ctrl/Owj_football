import express from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.OWJ_ADMIN_PASSWORD || 'CHANGE_THIS_ADMIN_PASSWORD';
const SESSION_SECRET = process.env.OWJ_SESSION_SECRET || 'CHANGE_THIS_SESSION_SECRET';
const DATA_DIR = path.join(__dirname, 'server-data');
const UPLOAD_DIR = path.join(DATA_DIR, 'players');
const PLAYERS_FILE = path.join(DATA_DIR, 'players.json');
const REGISTRATIONS_FILE = path.join(DATA_DIR, 'registrations.json');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const readJson = (file, fallback) => {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
};
const writeJson = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8');
if (!fs.existsSync(PLAYERS_FILE)) writeJson(PLAYERS_FILE, []);
if (!fs.existsSync(REGISTRATIONS_FILE)) writeJson(REGISTRATIONS_FILE, []);

app.use(express.json({ limit: '2mb' }));
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d' }));

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || '').toLowerCase() || '.jpg';
      cb(null, `${Date.now()}-${crypto.randomBytes(5).toString('hex')}${ext}`);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, /^image\/(jpeg|png|webp|gif)$/i.test(file.mimetype))
});

const sign = (payload) => {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
};
const verify = (token) => {
  try {
    const [body, sig] = token.split('.');
    const expected = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    return payload.exp > Date.now() ? payload : false;
  } catch { return false; }
};
const requireAdmin = (req, res, next) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!verify(token)) return res.status(401).json({ message: 'نشست مدیریت معتبر نیست.' });
  next();
};

const defaultPositionFa = { Goalkeeper: 'دروازه‌بان', Defender: 'مدافع', Midfielder: 'هافبک', Forward: 'مهاجم' };
const makePin = () => String(Math.floor(100000 + Math.random() * 900000));
const makePlayerId = (players) => `OWJ-${String(Math.max(0, ...players.map(p => Number(String(p.playerId || '').replace(/\D/g, '')) || 0)) + 1)}`;

app.post('/api/admin/login', (req, res) => {
  if (!req.body?.password || req.body.password !== ADMIN_PASSWORD) return res.status(401).json({ message: 'رمز مدیریت نادرست است.' });
  res.json({ token: sign({ role: 'admin', exp: Date.now() + 12 * 60 * 60 * 1000 }) });
});

app.get('/api/players', (_req, res) => {
  res.json({ players: readJson(PLAYERS_FILE, []) });
});

app.post('/api/player-registrations', upload.single('photo'), (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'عکس بازیکن الزامی است.' });
  const firstNameEn = String(req.body.firstNameEn || '').trim();
  const lastNameEn = String(req.body.lastNameEn || '').trim();
  const fullNameFa = String(req.body.fullNameFa || `${firstNameEn} ${lastNameEn}`).trim();
  if (!firstNameEn || !lastNameEn || !fullNameFa) return res.status(400).json({ message: 'نام و نام خانوادگی را کامل کنید.' });
  const position = ['Goalkeeper','Defender','Midfielder','Forward'].includes(req.body.position) ? req.body.position : 'Forward';
  const registrations = readJson(REGISTRATIONS_FILE, []);
  const registration = {
    id: crypto.randomUUID(),
    firstNameEn, lastNameEn, fullNameFa,
    photoUrl: `/uploads/${req.file.filename}`,
    createdAt: new Date().toISOString(),
    status: 'pending',
    jerseyNumber: Number(req.body.jerseyNumber || 0),
    position,
    positionFa: defaultPositionFa[position]
  };
  registrations.unshift(registration);
  writeJson(REGISTRATIONS_FILE, registrations);
  res.status(201).json({ registration });
});

app.get('/api/admin/player-registrations', requireAdmin, (_req, res) => {
  res.json({ registrations: readJson(REGISTRATIONS_FILE, []) });
});

app.post('/api/admin/player-registrations/:id/approve', requireAdmin, (req, res) => {
  const registrations = readJson(REGISTRATIONS_FILE, []);
  const index = registrations.findIndex(r => r.id === req.params.id);
  if (index < 0) return res.status(404).json({ message: 'درخواست پیدا نشد.' });
  const registration = registrations[index];
  if (registration.status !== 'pending') return res.status(409).json({ message: 'این درخواست قبلاً بررسی شده است.' });
  const players = readJson(PLAYERS_FILE, []);
  const jerseyNumber = Math.max(0, Number(req.body?.jerseyNumber ?? registration.jerseyNumber ?? 0));
  const position = ['Goalkeeper','Defender','Midfielder','Forward'].includes(req.body?.position) ? req.body.position : registration.position;
  const player = {
    id: `p-${crypto.randomUUID()}`,
    firstNameEn: registration.firstNameEn,
    lastNameEn: registration.lastNameEn,
    fullNameFa: registration.fullNameFa,
    username: `${registration.firstNameEn}${registration.lastNameEn}`.toLowerCase().replace(/\s+/g, ''),
    playerId: makePlayerId(players),
    pinCode: makePin(),
    jerseyNumber,
    position,
    positionFa: defaultPositionFa[position],
    photoUrl: registration.photoUrl,
    age: 0,
    heightCm: 0,
    weightKg: 0,
    preferredFoot: 'راست',
    isActive: true,
    stats: { matches: 0, goals: 0, assists: 0, yellowCards: 0, redCards: 0, cleanSheets: 0, minutesPlayed: 0 },
    attendanceStatus: 'excused',
    matchSquadStatus: 'not_selected'
  };
  players.push(player);
  writeJson(PLAYERS_FILE, players);
  registrations[index] = { ...registration, status: 'approved', playerId: player.playerId, pinCode: player.pinCode, jerseyNumber, position, positionFa: defaultPositionFa[position] };
  writeJson(REGISTRATIONS_FILE, registrations);
  res.json({ player, registration: registrations[index] });
});

app.post('/api/admin/player-registrations/:id/reject', requireAdmin, (req, res) => {
  const registrations = readJson(REGISTRATIONS_FILE, []);
  const index = registrations.findIndex(r => r.id === req.params.id);
  if (index < 0) return res.status(404).json({ message: 'درخواست پیدا نشد.' });
  registrations[index] = { ...registrations[index], status: 'rejected' };
  writeJson(REGISTRATIONS_FILE, registrations);
  res.json({ registration: registrations[index] });
});

// Serve the built Vite app when deployed as a single Node service.
const dist = path.join(__dirname, 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.listen(PORT, () => console.log(`OWJ server running on port ${PORT}`));
